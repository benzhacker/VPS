
<!DOCTYPE html>
<html lang="en" style="height: auto;
">
<head><head>

<meta charset="utf-8"/>
<!--<meta http-equiv="refresh" content="10;
url=
<?php echo base_url('index/'.$_SESSION['username'].'/logout')
?>" />-->
<meta name="stats-in-th" content="61de" />
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="description" content="บริการ VPN surin-vpn"/>
<meta name="keywords" content="Openvpn,vpn,nerfree,nettrue"/>
<meta name="author" content="surin-vpn"/>
<title>Ocspanel : บริการอินเตอร์เน็ตระบบ VPN ความเร็วสูง ไม่จำกัดแบนวิท ดูแลตลอดอายุการใช้งาน</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome-animation/0.2.1/font-awesome-animation.min.css">
<LINK HREF="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<LINK HREF="<?php echo base_url('asset/img/logobird.png')
?>" rel="shortcut icon" type="image/x-icon">
<LINK HREF="
<?php echo base_url('asset/css/bootstrap.min.css')
?>" rel="stylesheet"/>
<LINK HREF="
<?php echo base_url('asset/css/bootstrap.css')
?>" rel="stylesheet"/>
<LINK HREF="
<?php echo base_url('asset/dist/css/AdminLTE.min.css')
?>" rel="stylesheet"/>
<LINK HREF="
<?php echo base_url('asset/dist/css/skins/x.css')
?>" rel="stylesheet"/>
<LINK HREF="
<?php echo base_url('asset/css/bootstrap-dialog.min.css')
?>" rel="stylesheet"/>
<LINK HREF="
<?php echo base_url('asset/css/material-kitt.css')
?>" rel="stylesheet"/>
<LINK HREF="//netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.css" rel="stylesheet">
<LINK HREF="stylesheet" href="
<?php echo base_url('asset/css/buttons.css')
?>">

<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="
<?php echo base_url('asset/js/buttons.js')
?>"></script>

<!-- Custom Fonts -->
<LINK HREF='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<LINK HREF='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<LINK HREF="
<?php echo base_url('asset/font-awesome/css/font-awesome.min.css')
?>" rel="stylesheet"/>
<LINK REL="stylesheet" href="http://l-lin.github.io/font-awesome-animation/dist/font-awesome-animation.min.css">

<!-- Plugin CSS -->
<LINK HREF="
<?php echo base_url('asset/css/animate.min.css" type="text/css')
?>" rel="stylesheet"/>

<!-- Custom CSS -->
<LINK HREF="
<?php echo base_url('asset/css/creative.css" type="text/css')
?>" rel="stylesheet"/>
<LINK REL="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<!--[if lt IE 9]>
<script src="
<?php echo base_url('asset/js/html5shiv.js');

?>"></script>
<script src="
<?php echo base_url('asset/js/respond.min.js');

?>"></script>
<![endif]-->

<LINK REL="shortcut icon" href="
<?php echo base_url('shortcut icon" href="/favicon.ico" type="image/x-icon')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-57x57.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-72x72.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-76x76.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-114x114.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-120x120.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-144x144.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-152x152.png')
?>"/>
<LINK REL="shortcut icon" href="
<?php echo base_url('asset/img/apple-touch-icon/apple-touch-icon-180x180.png')
?>"/>
<LINK REL="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
<style type="text/css">
		<!--
		.style5 {color: #00CCFF;
 font-weight: bold;
 }
		.style7 {color: #00FF00;
 font-weight: bold;
 }
		-->
</style>
</head>

<body class="hold-transition skin-black fixed sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<header class="main-header">
<!-- Logo -->
<a href="" class="logo">
<!-- mini logo for sidebar mini 50x50 pixels -->

<?php foreach ($this->user_model->view_asset() as $row): 
?>

<?php if (empty($row['rekening'])):
?>

<?php if (empty($row['bank'])):
?>

<?php if (empty($row['pemilik'])):
?>
<!-- logo for regular state and mobile devices -->
<span class="logo-lg"><B> 
<?php echo $row['webname']
?> </B></span> </a>

<?php endif;

?>

<?php endif;

?>

<?php endif;

?>

<?php endforeach;
 
?>
<!-- Header Navbar: style can be found in header.less -->
<nav class="navbar navbar-static-top">
<!-- Sidebar toggle button-->
<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span>MENU <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
<div class="navbar-custom-menu">
<ul class="nav navbar-nav">
<li class="dropdown messages-menu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> เติมเงิน <i class="fa fa-level-down faa-flash animated"></i> <span class="label label-danger"> 3 </span> </a>

<ul class="dropdown-menu">
 <li class="header"> เลือกระบบการเติมเงิน</li>
 <li>
 <div class="slimScrollDiv" style="position: relative;
 overflow: hidden;
 width: auto;
 height: 200px;
">
 <ul class="menu" style="overflow: hidden;
 width: 100%;
 height: 200px;
">
 <li> <a href="<?php echo base_url('truewallet') ?>">
 <div class="pull-left"> <img src="<?php echo base_url('asset/img/t-wall.png') ?>"> </div>
 <h4> TRUEWALLET </h4>
 <p>เลขอ้างอิง</p>
 </a> </li>
 <li> <a href="<?php echo base_url('truemoney') ?>">
 <div class="pull-left"> <img src="<?php echo base_url('asset/img/payment-icon9.png') ?>"> </div>
 <h4> TRUEMONEY </h4>
 <p>บัตรเงินสด</p>
 </a> </li>
 <li> <a href="http://surin-vpn.tk">
 <div class="pull-left"> <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgRiQzYwFB0scvkrFKxCZBVcbdMWF8iCNAJN0qS4HPMjpuehuC"> </div>
 <h4> SCRIPT </h4>
 <p>เว็บไซต์ราคา 300 บาท </p>
 </a> </li>
 </ul>
 <div class="slimScrollBar" style="background: rgb(0, 0, 0);
 width: 3px;
 position: absolute;
 top: 0px;
 opacity: 0.4;
 display: none;
 border-radius: 7px;
 z-index: 99;
 right: 1px;
 height: 150px;
"></div>
 <div class="slimScrollRail" style="width: 3px;
 height: 100%;
 position: absolute;
 top: 0px;
 display: none;
 border-radius: 7px;
 background: rgb(51, 51, 51);
 opacity: 0.2;
 z-index: 90;
 right: 1px;
"></div>
 </div>
 </li>
 </ul>
</li>

?>
<!-- User Account: style can be found in dropdown.less -->
<div class="navbar-custom-menu">
<ul class="nav navbar-nav">
<li class="dropdown messages-menu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> PROFILE <i class="fa fa-level-down faa-flash animated"></i> </a>
 <ul class="dropdown-menu">
 <li class="header"> PROFILE </li>
 <li>
 <div class="slimScrollDiv" style="position: relative;
 overflow: hidden;
 width: auto;
 height: 200px;
">
 <ul class="menu" style="overflow: hidden;
 width: 100%;
 height: 200px;
">
 <li> <a href="
<?php echo base_url('index/'.$_SESSION['username'].'/setting')
?>" class=" waves-effect waves-light">
 <div class="pull-left"> <img src="https://image.flaticon.com/icons/png/512/206/206853.png" class="img-circle" alt="User Image"> </div>
 <h4> 
<?php echo $_SESSION['username'] 
?> <small><i class="fa fa-circle text-success"></i> ONLINE </small> </h4>
 <p><i class="fa fa-clock-o"></i> 
<?php echo $_SESSION['online_timestamp'] 
?></p>
 </a> </li>
 <li>
 <div class="text-center">
 <h4> เงินของคุณ : <small><i class="fa fa-clock-o"></i> ล่าสุด </small> </h4>
 <h1><b> 
<?php echo $_SESSION['saldo'] 
?> บาท </b></h1>
 </div>
 </li>
 <li class="footer"> <a href="
<?php echo base_url('index/'.$_SESSION['username'].'/logout')
?>" class="pull-right waves-effect waves-light"><b> ออกจากระบบ </b></a> <a href="
<?php echo base_url('index/'.$_SESSION['username'].'/setting')
?>" class="pull-left waves-effect waves-light"><b> เปลี่ยนรหัสผ่าน </b></a> </li>
 </ul>
 <div class="slimScrollBar" style="background: rgb(0, 0, 0);
 width: 3px;
 position: absolute;
 top: 0px;
 opacity: 0.4;
 display: none;
 border-radius: 7px;
 z-index: 99;
 right: 1px;
 height: 200px;
"></div>
 <div class="slimScrollRail" style="width: 3px;
 height: 100%;
 position: absolute;
 top: 0px;
 display: none;
 border-radius: 7px;
 background: rgb(51, 51, 51);
 opacity: 0.2;
 z-index: 90;
 right: 1px;
"></div>
 </div>
 </li>
 </ul>
 <!-- Control Sidebar Toggle Button -->
</div>
</nav>
</header>
<aside class="main-sidebar">
 <!-- sidebar: style can be found in sidebar.less -->
 <section class="sidebar">
 <!-- Sidebar user panel -->
 <div class="user-panel">
 <div class="pull-left image"> <img src="https://image.flaticon.com/icons/png/512/206/206853.png" alt="User Image" width="512" height="512" class="img-circle"> </div>
 <div class="pull-left info">
 
<?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): 
?>
 <p>
<?php echo $_SESSION['username'] 
?></p>
 <a href="#"><i class="fa fa-windows text-success"></i>
 
<?php if ($_SESSION['is_admin']) { echo "ADMIN";
 } else {echo "MEMBER";
 } 
?>
 </a> </div>
 </div>
 <!-- /.search form -->
 <!-- sidebar menu: : style can be found in sidebar.less -->
 <ul class="sidebar-menu">
 <li class="header">เมนู</li>
 
<?php if ($_SESSION['is_admin']): 
?>
 <li><a href="
<?php echo base_url('admin/index')
?>"><i class="glyphicon glyphicon-home text-info"></i> <span> หน้าแอดมิน </span></a></li>
 <li class="treeview"> <a href="#"> <i class="glyphicon glyphicon-th-large text-info"></i> <span>SERVER VPN ALL </span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('index/administrator/'.$_SESSION['username'].'/server') 
?>"><i class="	glyphicon glyphicon-sort-by-attributes"></i> รายชื่อเซิฟเวอร์</a></li>
 <li><a href="
<?php echo base_url('index/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') 
?>"><i class="glyphicon glyphicon-paste"></i> เพิ่มเซิฟเวอร์</a></li>
 </ul>
 </li>
 <li class="treeview"> <a href="#"> <i class="glyphicon glyphicon-th text-info"></i> <span>รายชื่อสมาชิก</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('useronline') 
?>"><i class="glyphicon glyphicon-sort-by-attributes"></i> สมาชิกทั้งหมด</a></li>
 <li><a href="
<?php echo base_url('index/admin/register/'.$_SESSION['username']) 
?>"><i class="fa fa-user-plus"></i> เพิ่มสมาชิก</a></li>
 </ul>
 </li>
 <li class="treeview"> <a href="#"> <i class="glyphicon glyphicon-th-large text-info"></i> <span>ตั้งค่าเว็บไซต์</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('admin/webname')
?>"><i class="glyphicon glyphicon-bookmark"></i> ข้อมูลเว็บและการติดต่อ</a></li>
 <li><a href="
<?php echo base_url('admin/all_filestrue')
?>"><i class="glyphicon glyphicon-download-alt"></i> ไฟล์ OVPN EHI ทั้งหมด</a></li>
 <li><a href="
<?php echo base_url('admin/all_filesdtac')
?>"><i class="glyphicon glyphicon-download-alt"></i> ไฟล์ OVPN ทั้งหมด DTAC</a></li>
 </ul>
 </li>
 <li class="treeview"> <a href="#"> <i class="	glyphicon glyphicon-th text-info"></i> <span>กิจกรรมและข่าวสาร</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('admin/event')
?>"><i class="glyphicon glyphicon-comment"></i> ข่าวกิจกรรม</a></li>
 <li><a href="
<?php echo base_url('admin/new_news')
?>"><i class="glyphicon glyphicon-comment"></i> ข่าวประกาศ</a></li>
 <li><a href="
<?php echo base_url('admin/pro_true')
?>"><i class="glyphicon glyphicon-phone"></i> เบอร์สมัครโปร TRUE</a></li>
 <li><a href="
<?php echo base_url('admin/pro_dtac')
?>"><i class="glyphicon glyphicon-phone"></i> เบอร์สมัครโปร DTAC</a></li>
 <li><a href="
<?php echo base_url('admin/pro_dtac')
?>"><i class="glyphicon glyphicon-phone"></i> เบอร์สมัครโปร AIS</a></li>
 <li><a href="
<?php echo base_url('admin/terms_use')
?>"><i class="glyphicon glyphicon-exclamation-sign"></i> เงื่อนไขการใช้งาน</a></li>
 </ul>
 </li>
 <li class="treeview"> <a href="#"> <i class="glyphicon glyphicon-signal text-info"></i> <span>ตั้งค่าการเติมเงิน</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('admin/wallet')
?>"><i class="fa fa-money"></i> ข้อมูลสำหรับเติมเงิน</a></li>
 <li><a href="
<?php echo base_url('/addpoint')
?>"><i class="fa fa-money"></i> เติมเครดิตให้สมาชิก</a></li>
 </ul>
 </li>
 </true>
 
<?php else: 
?>
 <li><a href="
<?php echo base_url('index')
?>"><i class="fa fa-fort-awesome"></i> <span> DASHBOARD </span></a></li>
 <li class="treeview"> <a href="#"> <i class="fa fa-cart-arrow-down"></i> <span> เลือกเเพ็คเกจ</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('servers') 
?>"><i class="fa fa-caret-right faa-passing animated text-aqua"></i> เซิร์ฟเวอร์ทั้งหมด</a></li>
 </ul>
 </li>
 <li class="treeview"> <a href="#"> <i class="glyphicon glyphicon-briefcase"></i> <span>เติมเงินระะบบอัตโนมัติ</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('truemoney') 
?>"><img src="
<?php echo base_url('assets/images/favicon.ico')
?>"</i> TRUE MONEY (อัตโนมัติ)</a></li>
 <li><a href="
<?php echo base_url('truewallet') 
?>"><img src="
<?php echo base_url('assets/images/favicon.ico')
?>"</i> TRUE WALLET (เลขอ้างอิง)</a></li>
 </ul>
 </li>
 <li class="treeview"> <a href="#"> <i class="fa fa-calendar"></i> <span> เช็ควันหมดอายุ</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 <li><a href="
<?php echo base_url('panel/reseller/cek_account/'.$_SESSION['username'].'')
?>"><i class="fa fa-slideshare" style="font-size: 16px;
 color:#4EA216"></i> เช็ควันใช้งาน</a></li>
 </ul>
 </li>
	 	 	
<?php foreach ($this->user_model->view_all_filesvpn() as $row): 
?>
			
<?php if (!empty($row['file_name'])): 
?>				
	 <li><a href="
<?php echo $row['file_name']
?>"><i class="fa fa-download"></i> <span>ไฟล์ OVPN EHI ทั้งหมด</span></a></li>
			
<?php endif;
 
?>
			
<?php endforeach;
 
?>
			 
	 	 	
<?php foreach ($this->user_model->view_all_programs() as $row): 
?>
			
<?php if (!empty($row['pritunl'])): 
?>							
			<li><a href="
<?php echo $row['pritunl']
?>"><i class="fa fa-download"></i> <span>ไฟล์ OVPN ทั้งหมด DTAC</span></a></li>
			
<?php endif;
 
?>
			
<?php endforeach;
 
?>	
					
	 		
<?php endif;
 
?>
 		
<?php endif;
 
?>
 <li class="header">เพิ่มเติม</li>
 <li class="treeview"> <a href="#"> <i class="fa fa-facebook"></i> <span>FACEBOOK</span> <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span> </a>
 <ul class="treeview-menu">
 
<?php foreach ($this->user_model->view_asset() as $row): 
?>
 
<?php if (!empty($row['fbchat'])): 
?>
 <li><a href="https://m.me/
<?php echo $row['fbchat']
?>"><i class="fa fa-envelope faa-ring animated"" style="font-size: 16px;
 color:#4EA216"></i> Messenger</a></li>
 
<?php if (!empty($row['fbface'])): 
?>
 <li><a href="https://facebook.com/
<?php echo $row['fbface']
?>"><i class="fa fa-facebook-official" style="font-size: 18px;
 color:#2B9EC4"></i> Facebook</a></li>
 
<?php if (!empty($row['fbgroup'])): 
?>
 <li><a href="https://www.facebook.com/groups/
<?php echo $row['fbgroup']
?>"><i class="fa fa-users" style="font-size: 13px;
 color:#FF5400"></i> Groups</a></li>
 
<?php endif;
 
?>
 
<?php endif;
 
?>
 
<?php endif;
 
?>
 
<?php endforeach;
 
?>
 </ul>
 <li><a href="
<?php echo base_url('index/'.$_SESSION['username'].'/setting')
?>"><i class="fa fa-cog"></i> <span> PROFILE EDIT </span></a></li>
 <li><a href="
<?php echo base_url('index/'.$_SESSION['username'].'/logout')
?>"><i class="glyphicon glyphicon-off text-danger"></i> <span>ออกจากระบบ</span></a></li>
 </ul>
 <br>
 <br>
 <br>
 </section>
 <!-- /.sidebar -->
</aside>
</body>
</html>
