<?php
/*
 * Copyright (c) 2008-2019 KU-LNW-POR <Kulnwpor@gmail.com>,
 * Truewallet id : 097-026-7262
 * 2008-2019 http://www.Ocspanel.info
*/
$host = 'localhost';
$user = 'root';
$pass = '123456789'; //ใส่รหัสครับ phpmyadmin
$db = 'OCS_PANEL';
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);


$walletmoney = $_POST['wallet'];
$walletuser = $_POST['user'];

ini_set('display_errors', 1);
include_once('manager/TrueWallet.php');
$wallet = new TrueWallet();

//ใส่ชื่อรหัส wallet ของคุณ
$username = "admin@admin.com";
$password = "123456789";

$wallet->logout();
