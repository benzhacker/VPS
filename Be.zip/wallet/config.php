<?php 
$host = 'localhost'; 
$user = 'scriptce_vpn';  // ตั้งค่า User ให้ตรงกับ MYSQL
$pass = 'benz194613';// ตั้งค่า passให้ตรงกับ MYSQL
$db = 'scriptce_vpnth'; // ตั้งค่า db ให้ตรงกับ MYSQL
$con = mysqli_connect($host,$user,$pass,$db); 
mysqli_set_charset($con,'utf8');
?>