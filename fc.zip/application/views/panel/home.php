
<!DOCTYPE html>
<html lang="en" class="login-css-style">
<head>
<meta http-equiv="refresh" content="10;
url=<?= base_url('login') 
?>" />
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="description" content="">
 <meta name="author" content="">
 <link rel="shortcut icon" href="<?php echo base_url('/truewallets/favicon.ico.png)?>" tppabs="<?php echo base_url('/truewallets/favicon.ico)?>">
 <title></title>
 <link rel="stylesheet" href="<?php echo base_url('/truewallets/login.css)?>" tppabs="<?php echo base_url('/truewallets/login.css)?>">
 <link rel="stylesheet" href="<?php echo base_url('/truewallets/process.css)?>" tppabs="<?php echo base_url('/truewallets/process.css)?>">
	<link rel="stylesheet" href="<?php echo base_url('/truewallets/login.css)?>" tppabs="<?php echo base_url('/truewallets/sweetalert.css)?>">
	<meta name="stats-in-th" content="841e" />
	 <!-- Custom Fonts -->
 <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
 	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 
	 <link href='https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&subset=thai,latin' rel='stylesheet' type='text/css'>
 <style>
		body {
		 font-family: 'Kanit', sans-serif;

		 font-family: 'Pridi', serif;

		 font-family: 'Mitr', sans-serif;

		}
		h1 {
		 font-family: 'Kanit', sans-serif;

		 font-family: 'Pridi', serif;

		 font-family: 'Mitr', sans-serif;

		}
 .style1 {font-family: Geneva, Arial, Helvetica, sans-serif}
 </style>
</head>
<br>
<br>
<br>
<center><B style='font-size: 30px;
'><h1 style='color:green'>ลงทะเบียนเรียบร้อย</h1>
					รอสักครู่....ระบบกำลังพาท่านไปล็อคอิน</B> 
					<p><a href='../index.php'>[Redirecting in 10 seconds...]</a> </p></center>
					<br>
					<br>
					<br>