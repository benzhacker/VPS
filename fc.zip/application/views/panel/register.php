<!DOCTYPE html>
<html>
 <head>
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <title>Ocspanel | Register</title>
 <!-- Tell the browser to be responsive to screen width -->
 <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 <!-- Bootstrap 3.3.5 -->
	<link href="<?php echo base_url('message/img/logobird.png')?>" rel="shortcut icon" type="image/x-icon">
 <link rel="stylesheet" href="<?php echo base_url('message/bootstrap/css/bootstrap.min.css')?>">
 <!-- Font Awesome -->
 <link rel="stylesheet" href="<?php echo base_url('message/dist/css/font-awesome.min.css')?>">
 <!-- Ionicons -->
 <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
 <!-- Theme style -->
 <link rel="stylesheet" href="<?php echo base_url('message/dist/css/AdminLTE.min.css')?>">
 <!-- iCheck -->
 <link rel="stylesheet" href="<?php echo base_url('message/plugins/iCheck/square/blue.css')?>">
 
 <link rel="icon" href="<?php echo base_url('message/img/favicon.png')?>" />
 
 <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
 <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
 <!--[if lt IE 9]>
 <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
 <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
 <![endif]-->
 <style type="text/css">
<!--
.style1 {color: #00FF00}
-->
 </style>
</head>
 <link href="https://fonts.googleapis.com/css?family=Itim" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Kanit:300" rel="stylesheet">
</head>
<style>
body {
 //font-family: 'Itim', cursive;

 font-family: 'Kanit', sans-serif;

}
</style>
<!-- WHITE BODY -->
 	<body>
<html lang="en" style="height: auto;
">
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<meta name="author" content="">
		<title>OPENVPN | VPN</title>
		
<!-- Custom Fonts -->
 <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
 <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
	
		
 
	<LINK REL="SHORTCUT ICON" HREF="http://เฮียเบิร์ด.com/all-img/asset/img/logobird.png"

		
	</head>
	
	
	<body class="skin-black-light fixed sidebar-mini" id="page-top" style="height: auto;
">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="MEMBER - VPN">
<meta name="author" content="MEMBER - VPN">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">


<nav id="mainNav" class="navbar navbar-default bg-dark navbar-fixed-top affix-top">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand page-scroll" href="/">
<img src="https://privatevpnservice.com/wp-content/uploads/2017/03/torguard-VPN.png" width="25px" style="display:inline;
 margin:0 2px 3px 0"> OPENVPN VPN</a></div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right">
<li>
<a class="page-scroll" href="<?php echo base_url('login')?>"> LOGIN </a></li>
<li>
<a class="page-scroll" href="https://www.facebook.com/ceolnw"> ADMIN CONTRACT </a></li>
</ul>
</div>
</div>
</nav><br><br><br>
<!-- WHITE BODY -->
 <body class="hold-transition login-page">
 <div class="login-box">
 <div class="login-logo">
 <img src="https://privatevpnservice.com/wp-content/uploads/2017/03/torguard-VPN.png" width="100" height="100" alt="" /> <br />
 <a href="<?php echo base_url('index')?>"><b>OPENVPN</b> REGISTER</a>
 </div>
 <!-- /.login-logo -->
 <div class="login-box-body">
				<?php if(validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo validation_errors() ?>
				</div>
			</div>
		<?php endif;
 ?>
		<?php if(isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo $error ?>
				</div>
			</div>
		<?php endif;
 ?>
		
 <?php echo form_open() ?>
 <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input required="required" id="username" type="text" class="form-control" onBlur="checkText();
" name="username" value="" placeholder="ใส่ไอดี ของคุณ" minlength="3">
</div>
 <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
<input required="required" id="Email" type="email" class="form-control" onBlur="checkText();
" name="email" value="" placeholder="ใส่อีเมล์ ของคุณ" minlength="3">
</div>
 <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-retweet"></i></span>
<input required="required" id="password" type="password" class="form-control" onBlur="checkText();
" name="password" value="" placeholder="ใส่รหัสผ่านอย่างน้อย 6 ตัว" minlength="3">
</div>
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input required="required" id="password_confirm" type="password" class="form-control" onBlur="checkText();
" name="password_confirm" value="" placeholder="ใส่รหัสผ่านอีกครั้ง" minlength="3">
</div>
 <div class="row">
 <div class="col-xs-8">
 <div class="checkbox icheck">
 <label>
 <a href="<?php echo base_url('/login')?>">Login Account</span></a> </label>
 </div>
 </div><!-- /.col -->
 <div class="col-xs-4">
 <button type="submit" class="btn btn-success btn-block btn-flat">Register</button>
 </div><!-- /.col -->
 </div>
 </form> 
   
 <b>
 <center>
 </div>
 </form>


</body>
</html>