<?php error_reporting(0); 
/*
 * Copyright (c) 2008-2019 KU-LNW-POR <Kulnwpor@gmail.com>,
 * Truewallet id : 097-026-7262
 * 2008-2019 http://www.Ocspanel.info
*/
$_CONFIG['TMN'][20]['point'] = 20; 
$_CONFIG['TMN'][50]['point'] = 43; 
$_CONFIG['TMN'][90]['point'] = 76; 
$_CONFIG['TMN'][150]['point'] = 150; 
$_CONFIG['TMN'][300]['point'] = 350; 
$_CONFIG['TMN'][500]['point'] = 580; 
$_CONFIG['TMN'][1000]['point'] = 1200; 

define('API_PASSKEY', '123456789'); 
require_once('AES.php'); 
$conn = mysql_connect("localhost","root","123456789"); 
mysql_select_db("OCS_PANEL",$conn); 
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"]; 

if($_SERVER['REMOTE_ADDR'] == '203.146.127.115' && isset($_GET['request'])) { $aes = new Crypt_AES(); 
$aes->setKey(API_PASSKEY); 
$_GET['request'] = base64_decode(strtr($_GET['request'], '-_,', '+/=')); 
$_GET['request'] = $aes->decrypt($_GET['request']); 
if($_GET['request'] != false) { parse_str($_GET['request'],$request); 
$request['Ref1'] = base64_decode($request['Ref1']); 
$result = mysql_query('SELECT * FROM users WHERE id =\'' . mysql_real_escape_string($request['Ref1']) . '\' LIMIT 1') or die(mysql_error()); 

if(mysql_num_rows($result) == 1) { $row = mysql_fetch_assoc($result); 

if(mysql_query('UPDATE users SET `saldo` = `saldo`+' . $_CONFIG['TMN'][$request['cardcard_amount']]['point'] . ' WHERE id =' . $row['id']) == false) { echo 'ERROR|MYSQL_UDT_ERROR|' . mysql_error(); 
} 
else { echo 'SUCCEED|UID=' . $row['id']; } 
} 
else { echo 'ERROR|INCORRECT_USERNAME'; } 
} 
else { echo 'ERROR|INVALID_PASSKEY'; } 
} 
else { echo 'ERROR|ACCESS_DENIED'; } 

?>