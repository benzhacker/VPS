<?php /**
            * Unreal Security - PHPMyLicense Check Class v2.5.0
            *
            * PHP version > 5
            *
            * LICENSE: This source file is subject to version 3.01 of the PHP license
            * that is available through the world-wide-web at the following URI:
            * http://www.php.net/license/3_01.txt.  If you did not receive a copy of
            * the PHP License and are unable to obtain it through the web, please
            * send a note to license@php.net so we can mail you a copy immediately.
            *
            * @package    PHPMyLicense
            * @author     Giovanne Oliveira <jhollsantos@gmail.com>
            * @copyright  2009 - 2015 PHPMyLicense
            * @license    http://www.php.net/license/3_01.txt  PHP License 3.01
            * @version    v3.0.0
            * @link       https://phpmylicense.com */
            
            $domain=$_SERVER['SERVER_NAME'];
            $product="44";
            $licenseServer = "http://php.xn--l3clxf6cwbe0gd7j.com/api/";

            $postvalue="domain=$domain&product=".urlencode($product);

            $ch = curl_init();
            curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_URL, $licenseServer);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postvalue);
            $result= json_decode(curl_exec($ch), true);
            curl_close($ch);

            if($result['status'] != 200) {
            $html = "<div align='center'>
    <table width='100%' border='0' style='padding:15px; border-color:#F00; border-style:solid; background-color:#FF6C70; font-family:Tahoma, Geneva, sans-serif; font-size:22px; color:white;'>

    <tr>

        <td><b>&#3605;&#3619;&#3623;&#3592;&#3614;&#3610;&#3617;&#3637;&#3585;&#3634;&#3619;&#3609;&#3635;&#3652;&#3611;&#3586;&#3634;&#3618; : <%returnmessage%> <br > &#3650;&#3611;&#3619;&#3604;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3605;&#3633;&#3623;&#3605;&#3609; https://m.me/ceolnw</b></td >

    </tr>

    </table>

</div>";
            $search = '<%returnmessage%>';
            $replace = $result['message'];
            $html = str_replace($search, $replace, $html);


            die( $html );

            }
            ?>