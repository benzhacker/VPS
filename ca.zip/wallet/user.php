<?php
SESSION_START();
include 'config.php';
if(!$_SESSION['user']['username']){
	header("location: login.php");
}

?>



<style type="text/css">
body {
background-image: url('https://plang-vpn.online/App/Really-Cool-Guy-Backgrounds-1024x576.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>

<html>
 <head> 
  <meta charset="utf-8"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <h2><title>HIGH SPEED SERVER</title></h2>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <link href="/wallet/bootstrap.min.css" rel="stylesheet"> 
  <link href="/wallet/material-dashboard.css" rel="stylesheet"> 
  <link href="/wallet/demo.css" rel="stylesheet"> 
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&amp;subset=thai,latin" rel="stylesheet" type="text/css"> 
  <style>
		body {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
		h1 {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
    </style> 
 </head>  


<center>
<a href="https://plang-vpn.online/wallet/wallet.jpg"><img src="https://images.cooltext.com/5070726.png" width="400" height="45" alt="AUTO TRUE WALLET" /></a>

 <?php
$sql = "select * from users where username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);

?>
<p>
<center>
<font color="#99FF66"><b>ชื่อผู้ใช้งาน : <?php echo $result['username'];?> </b></font></center></td></tr></table>


<center>
<font color="#99FF66"><b>เงินคงเหลือบัญชีนี้ : <?php echo $result['saldo'];?> บาท </b></font></center></td></tr></table> 

<center>
<a href="https://plang-vpn.online/wallet/wallet.jpg"><img src="https://images.cooltext.com/5070733.png" width="400" height="55" alt="นำหมายเลขอ้างอิงจากการโอนมาใส่
      ดูจากรายงานที่แอพ วอลเล็ท" /></a>
<br />
<p>
   
              <?php if (isset($user->saldo)) {echo $user->saldo; }?> 
             <form action="wallet.php" method="post"> 
            <div class="form-group"><center><font color="E63E37">



<p>
          </div>

             <input type="number" style="width:200px; height:35px;  border-radius:12px; border:5px" class="form-control text-center" maxlength="20" name="wallet"  placeholder=" ใส่เลขอ้างอิง 14หลัก" autofocus><p>
           </div>
<center>
            <input class="btn btn-info btn-round" class="form-control" type="submit" value="ยืนยันเลขอ้างอิง" name="wallet" onclick="this.disabled=1;this.value='รอสักครู่กำลังตรวจสอบเลขอ้างอิง...';document.forms[0].submit();loading()" style="width:200px; height:35px; border-radius:12px; font-size14px"> </center>
           </form> 
          </div> 
         </div> 
        </div> 
<a href="https://plang-vpn.online/wallet/wallet.jpg"><img src="https://images.cooltext.com/5071220.png" width="350" height="140" alt="KGUZA  r " /></a>


<a href="https://plang-vpn.online/wallet/wallet.jpg"><img src="https://images.cooltext.com/5071225.png" width="270" height="40" alt="ตัวอย่างการดู เลขที่อ้างอิง"</a>
<a href="https://wallet.truemoney.com"><img src="https://images.cooltext.com/5071227.png" width="270" height="40" alt="ถ้ายังไม่ใด้โอนเงินกดที่นี่เพื่อโอนเงินก่อน
" </a>
<br />
<center>
     
<marquee width="150">
<font color="#99FF66">
รับตัวแทนจำหน่ายvpnทางเราเปิดเวบให้พร้อมดูแลจัดการแบนวิทให้ท่านเพียงเช่าvpsมาลงในเวบที่เราเปิดให้ใด้เลยเวบเป็นของท่านทันทีสนใจติดต่อ กดที่คำว่า สมัครตัวแทน</font></h3><br></marquee></marquee>
<p>
<a href="http://line.me/ti/p/Dh6o2a5Ar9"><img src="https://images.cooltext.com/5071907.gif" width="150" height="50" alt="สมัครตัวแทน" /></a>

<a href="https://plang-vpn.online"><img src="https://images.cooltext.com/5071707.png" width="150" height="50" alt="กลับหน้าหลัก" /></a>





  <div class="amp-viewer-wrapper amp-viewer-is-touch" style="display: none;">
   <div class="amp-viewer">
    <div class="amp-viewer-header" style="transform: translate3d(0px, 0px, 0px);">
     <span class="amp-viewer-icon amp-viewer-icon-close">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewbox="0 0 100 125" style="enable-background:new 0 0 100 100;" xml:space="preserve">
       <path d="M88.8,77.5L60.6,49.3l28.2-28.2c1.2-1.2,1.2-3.1,0-4.2l-8.5-8.5L50,38.7L19.6,8.3l-8.5,8.5c-1.2,1.2-1.2,3.1,0,4.2  l28.2,28.2L11.2,77.5c-1.2,1.2-1.2,3.1,0,4.2l8.5,8.5L50,59.9l30.4,30.4l8.5-8.5C90,80.6,90,78.7,88.8,77.5z"></path>
      </svg></span>
     <div class="amp-viewer-header-main"></div>
    </div>
    <div class="amp-viewer-body" style="transform: translate3d(0px, 0px, 0px);"></div>
   </div>
  </div>
 </body>
</html>
