<?php
$host = 'localhost';
$user = 'root';
$pass = 'benz2539';//ใส่รหัสครับ phpmyadmin
$db = 'VPN_PANEL';
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con,'utf8');