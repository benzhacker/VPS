<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<center>
<style type="text/css">
body {
background-image: url('https://plang-vpn.online/App/Really-Cool-Guy-Backgrounds-1024x576.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
</center>
<a href="https://images.cooltext.com/5070835.png"><img src="https://images.cooltext.com/5070835.png" width="430" height="65" alt="สร้างบัญชี SSH-VPN S " /></a>
<br />
</div>

<marquee>
<font color="#00FFFF"> กรุณาทำความเข้าใจเซิร์ฟเวอร์ เว็บz.com ถ้ามีการใช้งานเกิน10 GB/ชัวโมง ทางเว็บจะมีการลดความเร็วและจะกลับเป็นปกติใน24ชั่วโมง »»ความเร็วจะอยู่ตามพื้นที่ใช้งานและโทรศัพท์ของคุณ  เพื่อรักษาความเร็วให้คงอยู่ตลอดกรุณา </font><font color="red"> { อย่าเทสสปีด }</font><font color="#00FFFF">ข้อความนี้ถือว่าท่านใด้ตกลงยอมรับเงื่อนไขแล้วทางเราจะไม่มีการคืนเงินหรือรับผิดชอบเรื่องความเร็วใดๆทั้งสิ้น!!ทั้งนี้เราก็จะหาเซิร์ฟเวอร์ที่เร็วที่สุดเท่าที่หาใด้มาให้บริการ!!</font></h3><br></marquee>
    <div class="row">
       <div class="col-xs-6 col-md-5 col-md-4 col-lg-3">
            <div class="btn btn-success" >เครดิตคงเหลือ : <B><?php if (isset($user->saldo)) {echo $user->saldo; }?></B>
</div>
</div>
<p>&nbsp;</p>
</div>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
           <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <b><?= $server->ServerName ?></b>
                    </div>
                    <div class="panel-body">
					<?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-success" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-success" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?= form_open() ?>
						<div class="form-group">
							<label for="username">ชื่อผู้ใช้</label>
							<input type="text" name="username" name="password" class="form-control" id="username" id="password" placeholder="ตัวเลขหรือตัวอักษร อย่างน้อย 1ตัว"/>
						</div>
							 <div class="form-group">
                            <font color="red"><center>รหัสผ่านแสดงหลังจากสร้างบัญชี</center></font>
                            <input class="hide" style="width:0px; border:0px" type="text" name="password" id="password" value="1234" readonly>
                        </div>
                    
                    </div>
                    <div class="panel-footer text-center">
                    <input type="submit" class="btn btn-success" value="สร้างบัญชี"/>
<a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>" class="btn btn-danger">ย้อนกลับ</a>
<a href="http://line.me/ti/p/Dh6o2a5Ar9" class="btn btn-warning "></i>สอบถาม</a></form>            
                </div>
            </div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

    </div>
</div>