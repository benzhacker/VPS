<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<style type="text/css">
body {
background-image: url('https://plang-vpn.online/App/Free-simple-backgrounds-free-1024x576.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
</center>
  <center>
            <h2 class="page-header">
               <font color="#99FF66"> บัญชี SSH-VPN</center></font>
            </h2>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12 hidden-print">                    
                <?= $user['message']?>
            </div>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-user fa-fw"></i><font color="#8A2BE2"> สร้างบัญชีสำเร็จก็อปปี้ข้อมูลไปใส่ในแอพต่างๆ
                </div>
                <div class="panel-body">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <td>ชื่อผู้ใช้</td><td>:</td><td><?= $user['username']?></td>
                        </tr>
                        <tr>
                            <td>รหัสผ่าน</td><td>:</td><td><?= $user['password']?></td>
                        </tr>
                        <tr>
                            <td>โฮส IP</td><td>:</td><td><?= $user['hostname']?></td>
                        </tr>
                        <tr>
                            <td>ประเทศ</td><td>:</td><td><?= $user['location']?></td>
                        </tr>
                        <tr>
                            <td>Openssh</td><td>:</td><td><?= $user['openssh']?></td>
                        </tr>
                         <tr>
                            <td>Dropbear</td><td>:</td><td><?= $user['dropbear']?></td>
                        </tr>
                         <tr>
                            <td>ราคา</td><td>:</td><td><?= $user['price']?></td>
                        </tr>
                        <tr>
                            <td>วันหมดอายุ</td><td>:</td><td><?= date("Y-m-d H:i:s",strtotime("+".$user['expired']." days", time() ) )?></td>
                        </tr>
                    </tbody>
                </table>
                <p class="text-muted">
                   <p><font color="red">คำเตือน!!! 1 บันชีห้ามใช้งานเกิน 2เครื่องในเวลาเดียวกัน ถ้าฝ่าฝื้นกฎ ระบบจะลบบันชีของคุณโดยอัตโนมัติ
อย่ารีเควสหน้านี้มิเช่นนั้นเครดิทท่านจะถูกหักอัตโนมัติ { ให้กดย้อนกลับ }
                </p></font>
                <div class="hidden-print">
					   <a href="http://<?= $user['hostname']?>:81/ConfigPanel/HighSpeedServers.ovpn" class="btn btn-success"><i class="fa fa-download fa-fw"></i> โหลดไฟล์คอนฟิค</a>
					<a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>" class="btn btn-danger">ย้อนกลับ</a>
          <a href="http://line.me/ti/p/Dh6o2a5Ar9" class="btn btn-warning "></i>สอบถาม</a>
					</div>
				</div>
        </div>
    </div>
</div>
