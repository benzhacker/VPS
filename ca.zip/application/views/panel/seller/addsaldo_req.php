<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<style type="text/css">
body {
background-image: url('https://plang-vpn.online/App/Black-Background-1024x576.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
<center>
            <a href="https://plang-vpn.online/wallet/user.php"><img src="https://images.cooltext.com/5070698.png" width="400" height="100" alt="เติมเงินเข้าระบบด้วยทรูวอลเล็ท" /></a>
<br />

<marquee>
<font color="#00FFFF"> กรุณาทำความเข้าใจเซิร์ฟเวอร์ เว็บz.com ถ้ามีการใช้งานเกิน10 GB/ชัวโมง ทางเว็บจะมีการลดความเร็วและจะกลับเป็นปกติใน24ชั่วโมง »»ความเร็วจะอยู่ตามพื้นที่ใช้งานและโทรศัพท์ของคุณ  เพื่อรักษาความเร็วให้คงอยู่ตลอดกรุณา </font><font color="red"> { อย่าเทสสปีด }</font><font color="#00FFFF">ข้อความนี้ถือว่าท่านใด้ตกลงยอมรับเงื่อนไขแล้วทางเราจะไม่มีการคืนเงินหรือรับผิดชอบเรื่องความเร็วใดๆทั้งสิ้น!!ทั้งนี้เราก็จะหาเซิร์ฟเวอร์ที่เร็วที่สุดเท่าที่หาใด้มาให้บริการ!!</font></h3><br></marquee>

  <div class="btn btn-info" class="well"><b>เครดิตคงเหลือ : <B><?= $user -> saldo ?> บาท</b>
             </div>
<center>
  <form method="post" action="http://plang-vpn.online/wallet/check.php"><strong>

<font color="99FF66"><h4>
<p><b>โอนทรูวอลเล็ทมาที่เบอร์นี้ก่อน</b>
<p><font color="#FFA500"><h3><b>0923268286</h3></b>
<p><font color="#99FF66">โอนแล้วให้คลิกดำเนินการต่อ<p>
<p>จำนวนที่สามารถเติมออโต้ได้มีดังนี้<p>
<p>ตั้งแต่ { 1บาท } ถึง { 300บาท }</p></h4>
<p>&nbsp;</p>
</center>
<center>
<p>&nbsp;</p>
<p>&nbsp;</p>
<a href="https://plang-vpn.online/wallet/user.php"><img src="https://images.cooltext.com/5071696.png" width="269" height="30" alt="ดำเนินการต่อ" /></a>
  <input name="user"type="text" class="form-control text-center" id="user"  style="width:270px; border:2px #ffffff solid;" value="<?= $_SESSION['username'] ?>" maxlength="14"input type="text" name="text1" readonly />
  <br />
  <input class="btn btn-success" type="submit" value="ดำเนินการต่อ" />
<a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>" class="btn btn-danger">ย้อนกลับ</a>
<a href="http://line.me/ti/p/Dh6o2a5Ar9" class="btn btn-warning "></i>สอบถาม</a>
</center>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
  </form>
        </div>
      </div>
    </div>
  </div>
</div>
