<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>


<style type="text/css">
body {
background-image: url('https://plang-vpn.online/App/Free-simple-backgrounds-free-1024x576.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>

<a href="https://images.cooltext.com/5071667.png"><img src="https://images.cooltext.com/5070795.png" width="460" height="65" alt="<center class="page-header"><font color="#99FF66">
 </a></font>
<br />

<marquee>
<font color="#00FFFF"> กรุณาทำความเข้าใจเซิร์ฟเวอร์ เว็บz.com ถ้ามีการใช้งานเกิน10 GB/ชัวโมง ทางเว็บจะมีการลดความเร็วและจะกลับเป็นปกติใน24ชั่วโมง »»ความเร็วจะอยู่ตามพื้นที่ใช้งานและโทรศัพท์ของคุณ  เพื่อรักษาความเร็วให้คงอยู่ตลอดกรุณา </font><font color="red"> { อย่าเทสสปีด }</font><font color="#00FFFF">ข้อความนี้ถือว่าท่านใด้ตกลงยอมรับเงื่อนไขแล้วทางเราจะไม่มีการคืนเงินหรือรับผิดชอบเรื่องความเร็วใดๆทั้งสิ้น!!ทั้งนี้เราก็จะหาเซิร์ฟเวอร์ที่เร็วที่สุดเท่าที่หาใด้มาให้บริการ!!</font></h3><br></marquee>

<font color="red"><center>เซิร์ฟเวอร์ VIP รับความเร็วเต็มสปีด ใช้เซิร์ฟเวอร์สเป็คสูง</center></font>

            <div class="dropdown pull-right">
				<a href="<?= base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/addsaldo-via-req') ?>" class="btn btn-info">เติมเครดิต</a>
            </div> 
        </div>
    </div>



            <div class="btn btn-info" class="well">เครดิตคงเหลือ : <B><?= $user -> saldo ?>
             </div>
           </div>
         </div>

       <div class="row">
           <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>         
                <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-success">
                    <div class="panel-heading">
                   
                        <b><?= $row['ServerName']?></b> <?php if ($row['Status']) { echo '';} else {echo "[ เต็ม ] [ เซิร์ฟเวอร์จะเพิ่มเร็วๆ นี้ ]";}?>
                    </div>
                    <table class="table">
                        <tr>
                            <td>ประเทศ</td><td><?= $row['Location']?></b></td>
                        </tr>
                        <tr>
                            <td>โฮส</td><td> แสดงหลังจากซื้อแพคเกจ</b></td>
                        </tr>
                               <tr>
                            <td>ระยะเวลาใช้งาน</td><td> <?= $row['Expired']?> วัน</td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td><?= $row['Price']?> บาท</b></td>
                        </tr>
                    </table>
                   <div class="panel-footer text-left">
<a href="http://<?= $row['HostName']?>:81/ConfigPanel/HighSpeedServers.ovpn"class="btn btn-success"><i class="fa fa-download fa-fw"></i>โหลดไฟล์คอนฟิค</a>
                        <a href="<?= base_url('panel/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-danger"><i class="fa fa-shopping-cart fa-fw"></i> ซื้อแพคเกจ</a>
                        <a href="http://line.me/ti/p/Dh6o2a5Ar9" class="btn btn-warning "></i>สอบถาม</a>
                        <!-- <a href="http://{{ @server->host }}:81/vpn-config.rar" class="btn btn-success"><i class="fa fa-download fa-fw"></i> VPN Config</a> -->
                    </div>
                </div>
            </div>
      <?php endforeach; ?>
    </div>
</div>
