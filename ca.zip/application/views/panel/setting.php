<style type="text/css">
body {
background-image: url('https://plang-vpn.online/App/Free-simple-backgrounds-free-1024x576.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
         
      <center class="page-header">
   <a href="https://images.cooltext.com/5070774.png"><img src="https://images.cooltext.com/5070774.png" width="360" height="65" alt="ตั้งค่าเปลี่ยนรหัสผ่าน" /></a></center>
 </div>
    </div>
			<?php if (isset($message)) {echo $message; }?>
			<?php if (isset($success)) {echo $success; }?>
            </i> 
<center>
<p><font color="#99FF66"><h3>เปลี่ยนรหัสผ่านการเข้าสู้หน้าเว็บ</h3></center></font></p>
                </div>
                <div class="panel-body">
                    <form role="form" action="<?= base_url('panel/'.$_SESSION['username'].'/setting')?>" method="POST">
						<input type="hidden" name="username" value="<?= $_SESSION['username'] ?>">
                        <div class="form-group">
                            <label><font color="#99FF66">รหัสผ่านเดิม</font></label>
                            <input class="form-control" placeholder="รหัสผ่านเดิม" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label><font color="#99FF66">รหัสผ่านใหม่</font></label>
                            <input class="form-control" placeholder="รหัสผ่านใหม่" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label><font color="#99FF66">ยืนยันรหัสผ่าน</font></label>
                            <input class="form-control"
 placeholder="ยืนยันรหัสผ่าน" name="passconf" type="password" required>
                        </div>
                        <button class="btn btn-success">บันทึก</button>
<p>&nbsp;</p>
                    </form>
                </div>
            </div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
        </div>
    </div>
</div>

