<?php echo '

';
SESSION_START();
include 'connection.php';
if(!$_SESSION['user']['username']){
header("location: /");
}
$sql = "select * from users where username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);
if( $result['username']){
}else{
header("location: /");
}
;echo '	
	
'; ?>