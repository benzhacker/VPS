<?php 
SESSION_START();
include_once 'config.php';
if(!$_SESSION['user']['username']){
header("location: /");
}
;echo '	

';
$line_api = 'https://notify-api.line.me/api/notify';
$access_token = 'J1pIbN7NXPOVxyOjqlAY1VceV4kCOz5LL46BiiNepv5';
require_once './api.php';
date_default_timezone_set('Asia/Bangkok');
$wallet = new APIsWallet('sakariyamisayalong@gmail.com','Kariya4468');
$ref1 = $_POST['wallet'];
$ref2 = $_POST['member'];
$start_date = date('Y-m-d',strtotime('-365 days'));
$end_date = date('Y-m-d',strtotime('1 days'));
$token = json_decode($wallet->A(),true)['data']['accessToken'];
$c = json_decode($wallet->B($token,$start_date,$end_date),true)['data']['activities'];
foreach($c as $reports) {
if($reports['text3En'] == 'creditor') {
$txData = json_decode($wallet->E($token,$reports['reportID']),true);
$d['id'] = $txData['data']['section4']['column2']['cell1']['value'];
$d['message'] = $txData['data']['personalMessage']['value'];
$d['fee'] = $txData['data']['section3']['column2']['cell1']['value'];
$d['date'] = $txData['data']['section4']['column1']['cell1']['value'];
$d['sender']['name'] = $txData['data']['section2']['column1']['cell2']['value'];
$d['sender']['phone'] = $txData['data']['ref1'];
$d['amount'] = $txData['data']['section3']['column1']['cell1']['value'];
$dd = str_replace(',','',$d['amount']);
$name = str_replace(',','',$d['sender']['name']);
$namberphone = str_replace(',','',$d['sender']['phone']);
if ($d['id'] === $ref1) {
$sql = "select * from users where username='".$ref2."'";
$sqle = "select * from histrory where NumberWallet='$ref1'";
$query = mysqli_query($con,$sqle);
$result = mysqli_fetch_assoc($query);
if($result['status'] == ''){
$statuswl='ได้เติมเงินจำนวน '.$dd.'  บาทสำเร็จ';
$sql = "insert into histrory (NumberWallet,money,NumberPhone,username,status) values ('$ref1','$dd','$namberphone','".$ref2."',1)";
$smile = sm1234;
$str ='
******************
 🤵 '.$ref2.'
 ⏳ เติมเงิน '.$dd.' บาท
 📶 '.$namberphone.'
  ♻️ '.$ref1;
mysqli_query($con,$sql);
$sql1 = "insert into users (saldo) values ('$dd') where username='".$ref2."'";
$sql1 = "update users set saldo=saldo+'".$dd."'where username='".$ref2."'";
mysqli_query($con,$sql1) or die;('Error Query');
}else{
echo '<div class="col-md-4 col-md-offset-4">
<p style="width:210px; border:1px" class="alert alert-warning">เลขอ้างอิงถูกใช้งานแล้ว </p>

';
$statuswl='ได้ใช้หมายเลขอ้างอิงที่ถูกใช้งานแล้ว';
$smile = smile4468;
$str ='
******************
 🤵 '.$ref2.'
 ⏳ ใช้เลขอ้างอิงซ้ำ
 ♻️ '.$ref1;
}
break;
}else{
$smile = smile4468;
echo '<div class="col-md-4 col-md-offset-4">
<p style="width:210px; border:1px" class="alert alert-danger">รายการผิดพลาด...? </p>';
$str ='
******************
 🤵 '.$ref2.'
 📵 รายการผิดพลาด
 ♻️ '.$ref1;
break;
}
}
}
if ($smile == 'sm1234') {
include 'config.php';
$sql = "select * from users where username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);
$smil = $result['saldo'];
echo '<div class="col-md-4 col-md-offset-4">
<p style="width:210px; border:1px" class="alert alert-success"> '.$name.'<br> ได้เติมเงิน '.$dd.'  บาทสำเร็จ<br> ยอดร่วม '.$smil.' บาท</p>
';
}else {
}
;echo '	
	'; ?>