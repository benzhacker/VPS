<?php echo '<meta charset="UTF-8">
';
include('smile.php');
$id = $_REQUEST["id"];
$sql = "DELETE FROM users WHERE id='$id' ";
$result = mysqli_query($con,$sql) or die ("Error in query: $sql ".mysqli_error());
if($result){
echo "<script type='text/javascript'>";
echo "alert('delete Succesfuly');";
echo "window.location = './'; ";
echo "</script>";
}
else{
echo "<script type='text/javascript'>";
echo "alert('Error back to delete again');";
echo "</script>";
}; ?>