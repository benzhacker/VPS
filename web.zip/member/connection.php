<?php echo '
';
include_once '../application/config/database.php';
$host = $db['default']['hostname'];
$user = $db['default']['username'];
$pass = $db['default']['password'];
$db = $db['default']['database'];
$con= mysqli_connect($host,$user,$pass,$db) or die("Error: ".mysqli_error($con));
mysqli_query($con,"SET NAMES 'utf8' "); ?>