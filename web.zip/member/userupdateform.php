<?php echo '<br><br><br><br><br>
<meta charset="UTF-8">
<html>
	
 <head> 
  <meta charset="utf-8"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <title>แก้ไข</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&amp;subset=thai,latin" rel="stylesheet" type="text/css"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
  <style>
		body {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
		h1 {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
    </style> 
    <style type="text/css">
body {
background-image: url(\'/asset/imega/bg.JPG\');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
 </head>

';
include('smile.php');
$id = $_REQUEST["id"];
$sql = "SELECT * FROM users WHERE id='$id' ";
$result = mysqli_query($con,$sql) or die ("Error in query: $sql ".mysqli_error());
$row = mysqli_fetch_array($result);
extract($row);
;echo '<body class="hold-transition register-page"> 
  <div class="register-box"> 
   <section class="content"> 
    <div class="main-panel"> 
     <div class="content"> 
      <div class="container-fluid"> 
       
         <div class="card card-profile"> 
          <div class="card-avatar"> 
             
          </div> <center>
					<div class="row">
        <div class="col-lg-12">
					<div class="panel panel-primary">
						<div class="panel-heading"><h3>เพิ่มจำนวนเครดิต</h3></div>
						<div class="panel-body">
							<form action="userupdate_db.php" method="post" name="updateuser" id="updateuser">
							
								<div class="form-group">
									<label for="username"></label>
									<input class="hide" type="text" name="id" value="';echo $id;;echo '" disabled=\'disabled\' />
                               <input class="hide" type="hidden" name="id" value="';echo $id;;echo '" />
										<p class="help-block"></p>
								</div>
								<div class="form-group">
									<label for="username">ชื่อผู้ใช้</label>
									<input class="text-center form-control" id="username" name="username" value="';echo $username;;echo '" disabled=\'disabled\'  />
										<p class="help-block"></p>
								</div>
								
								<div class="form-group">
									<label for="saldo">เครดิต</label>
									<input type="number" class="text-center form-control" id="saldo" name="saldo" placeholder="จำนวนเครดิตที่จะเพิ่ม"  required="required"/>
									<p class="help-block"></p>
								</div>
								<div class="form-group">
								<input class="btn btn-danger" type="button" value=" ยกเลิก " onclick="window.location=\'/admin/view_users\' " /> <!-- ถ้าไม่แก้ไขให้กลับไปหน้าแสดงรายการ -->
        &nbsp;
        <input class="btn btn-primary" type="submit" name="Update" id="Update" value="เพิ่มเครดิต" /></td>
								</div>
</form></center>
						</div>
					</div>
				</div></div><!-- .row -->
		</div>
</div> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
     <div>
     </div> 
    </div>
   </section>

  </div> 
  <div class="amp-viewer-wrapper amp-viewer-is-touch" style="display: none;">
   <div class="amp-viewer">
    <div class="amp-viewer-header" style="transform: translate3d(0px, 0px, 0px);">
     <span class="amp-viewer-icon amp-viewer-icon-close">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewbox="0 0 100 125" style="enable-background:new 0 0 100 100;" xml:space="preserve">
       <path d="M88.8,77.5L60.6,49.3l28.2-28.2c1.2-1.2,1.2-3.1,0-4.2l-8.5-8.5L50,38.7L19.6,8.3l-8.5,8.5c-1.2,1.2-1.2,3.1,0,4.2  l28.2,28.2L11.2,77.5c-1.2,1.2-1.2,3.1,0,4.2l8.5,8.5L50,59.9l30.4,30.4l8.5-8.5C90,80.6,90,78.7,88.8,77.5z"></path>
      </svg></span>
     <div class="amp-viewer-header-main"></div>
    </div>
    <div class="amp-viewer-body" style="transform: translate3d(0px, 0px, 0px);"></div>
   </div>
  </div>
  </center>
 </body>
</html> '; ?>