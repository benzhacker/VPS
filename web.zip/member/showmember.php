<?php echo '
	



<html>
	
 <head> 
     </center>
  <meta charset="utf-8"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <title>รายชื่อสมาชิกทั้งหมด</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&amp;subset=thai,latin" rel="stylesheet" type="text/css"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
  <style>
		body {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
		h1 {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
    </style> 
    <style type="text/css">
body {
background-image: url(\'/asset/imega/bg.JPG\');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
 </head>
<center> <div class="btn btn-danger><font color="#ff0000">ค้นหาด้วยชื่อผู้ใช้หรือยอดเครดิต</center> </div></font>
 <form name="frmSearch" method="get" action="';echo $_SERVER['SCRIPT_NAME'];;echo '">
   <center>   <input name="txtKeyword" type="text" id="txtKeyword" value="';echo $_GET["txtKeyword"];;echo '">   <input class="btn-info" type="submit" value="ค้นหา">  <a class="btn-danger" href="/panel/administrator/smilevpn/server" > ย้อนกลับ </a></center>
   
</form>
 <body class="hold-transition register-page"> 
  <div class="col-md-12">
             
          </div> 
          




              


	<table border=\'2\' align=\'center\' width=\'98%\'>

<tr align=\'center\' bgcolor=\'#CCCCCC\'><td>ลำดับ</td><td>ชื่อผู้ใช้</td><td>เครดิต</td><td>  เพิ่ม  </td><td>  แก้ไข  </td><td>  ลบ  </td></tr>
	';
include 'smile.php';
$query = "SELECT * FROM users WHERE (username LIKE '%".$_GET["txtKeyword"]."%' or saldo LIKE '%".$_GET["txtKeyword"]."%' or email LIKE '%".$_GET["txtKeyword"]."%' )";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_array($result)) {
echo "<tr align='center' bgcolor='#ffffff'>";
echo "<td> ".$row["id"] ."</td> ";
echo "<td> ".$row["username"] ."</td> ";
echo "<td> ".$row["saldo"] ."</td> ";
echo "<td>  <a href='userupdateform.php?id=$row[0]'> ♻️ </a>  </td> ";
echo "<td>  <a href='edit.php?id=$row[0]'> 📝 </a>  </td> ";
echo "<td> <a href='UserDelete.php?id=$row[0]' onclick=\"return confirm('แน่ใจต้องการลบผู้ใช้ชื่อนี้..? !!!')\"> ❌ </a>  </td> ";
echo "</tr>";
}
echo "</table>";
mysqli_close($con);
;echo '	<br>
</div> 
         
   

  </div> 
  <div class="amp-viewer-wrapper amp-viewer-is-touch" style="display: none;">
   <div class="amp-viewer">
    <div class="amp-viewer-header" style="transform: translate3d(0px, 0px, 0px);">
     <span class="amp-viewer-icon amp-viewer-icon-close">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewbox="0 0 100 125" style="enable-background:new 0 0 100 100;" xml:space="preserve">
       <path d="M88.8,77.5L60.6,49.3l28.2-28.2c1.2-1.2,1.2-3.1,0-4.2l-8.5-8.5L50,38.7L19.6,8.3l-8.5,8.5c-1.2,1.2-1.2,3.1,0,4.2  l28.2,28.2L11.2,77.5c-1.2,1.2-1.2,3.1,0,4.2l8.5,8.5L50,59.9l30.4,30.4l8.5-8.5C90,80.6,90,78.7,88.8,77.5z"></path>
      </svg></span>
     <div class="amp-viewer-header-main"></div>
    </div>
    <div class="amp-viewer-body" style="transform: translate3d(0px, 0px, 0px);"></div>
   </div>
  </div>
  </center>
  </center>
 </body>
</html>'; ?>