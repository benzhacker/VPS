<?php 
SESSION_START();
include 'smile.php';
if(!$_SESSION['user']['username']){
header("location: /");
}else {
header("location: /admin/view_users");
}
;echo '	'; ?>