<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">ดาวน์โหลดไฟล์
            </h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> เลือกดาวน์โหลดไฟล์
                </div>
                
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
           
                            <thead>
							<tr><th><center>เซิฟร์เวอร์</center></th><th><center>ซิมที่รองรับ</center></th><th><center>โปรที่ต้องสมัคร</center></th><th><center>download</center></th></tr>
                        </thead>
                        <tbody>
                            
							
					
						
							
							
							<?php if (empty($row['nohp'])):?>
						<?php foreach ($this->user_model->view_ovpn() as $row): ?>
							<tr>
								
								
								<td><center><?= $row['server']?></center></td>
								
								<td><center><?= $row['sim']?></center></td>
								<td><center><?= $row['pro']?></center></td>
								<td><center><a href="<?= $row['link']?>"><span class="fa fa-arrow-circle-o-down"></span></a></center></td>
									
									
					
                                             </tr>
                                             
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                            <td class="text-muted text-center" colspan="12"> แอดมินยังไม่ได้ตั้งค่าการดาวน์โหลดไฟล์</td>
                                        </tr>
                                        <?php endif; ?>
                                   
                            </tbody>
                        </table>
                    </div>
                </div>
				
            </div>
        </div>
    </div>
</div>
