<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<?php
$today= date("Y,m,d");
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">เซิฟร์
                <small><?= $server -> HostName ?></small>
                </h3>
                
            <a href="<?= base_url('seller/buy/'. $server->Id )?>" class="btn btn-primary pull-right"><i class="fa fa-plus fa-fw"></i> เพิ่มบัญชี</a>
        </div>
    </div>
    
    <h3></h3>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> รายการบัญชี
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><center>
                                <tr>
                                    <th><center>ไอดี</center></th>
                                    <th><center>ชื่อผู้ใช้</center></th>
                                  <th><center>รหัสผ่าน</center></th>
                                    <th><center>สร้างโดย</center></th>
                                    <th><center>วันที่สร้าง</center></th>
                                    <th><center>วันหมดอายุ</center></th>
                                    <th><center>สถานะ</center></th>
                                    <th><center>ดาวน์โหลด</center></th>
                                    
                                    <th><center>ลบออก</center></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($user)): ?>
                                        <?php foreach ($user as $row): ?>
                                            <tr>
                                                <td><center><?= $row['id'] ?></center></td>
                                                <td><center><?= $row['username'] ?></center></td>
                                                <td><center><?= $row['password'] ?></center></td>
                                                <td><center><?= $row['created_by']?></center></td>
                                                <td><center><?= $row['created_at']?></center></td>
                                                <td><center><?= $row['expired_at']?></center></td>
                                                <td><center> <?php
if ($today <= $row['expired_at'] ){
	?>
เหลืออีก<script> 
var montharray=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
 
function countup(yr,m,d){
var today=new Date()
var todayy=today.getYear()
if (todayy < 1000)
todayy+=1900
var todaym=today.getMonth()
var todayd=today.getDate()
var todaystring=montharray[todaym]+" "+todayd+", "+todayy
var paststring=montharray[m-1]+" "+d+", "+yr
var difference=(Math.round((Date.parse(paststring)-Date.parse(todaystring))/(24*60*60*1000))*1)
difference+=" "
document.write(" "+difference+" ")
}
//พิมพ์วันเรียงตามดังนี้  ( ปี ค.ศ./เดือน/วัน)
countup(<?= $row['expired_at']?>)
                  </script> วัน
<?php
} else {
	echo '<center><font color="red">หมดอายุแล้ว</font></center>';
	?>
		
		<?php
	}
?></center></td>
                                                
                                                
                                                 
                                                <td><center>
                                                    <a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/download') ?>" ><i class="fa fa-arrow-circle-down"></i></a>
                                            </center>    </td>
                                                <td><center>
                                                    <a href="<?= base_url('admin/delet_account/'. $row['id'])?>" <span class="fa fa-trash-o fa-sm"></span></a>
                                                </center></td>
                                             </tr>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                       <center>     <td class="text-muted text-center" colspan="6"> ไม่มีผู้ใช้</center></td>
                                        </tr>
                                   <?php endif; ?>
                           </center> </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
