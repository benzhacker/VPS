<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">รายชื่อสมาชิกทั้งหมด
                
                </h3>
                
        </div>
    </div>
    
    <h3></h3>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> สมาชิกทั้งหมด
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead><center>
                                <tr>
                                    <th><center>โปรไฟล์</center></th>
                                    <th><center>ชื่อผู้ใช้</center></th>
                                  <th><center>เครดิต</center></th>
                                    <th><center>สถานะ</center></th>
                                    <th><center>วันที่เป็นสมาชิก</center></th>
                                    
                                    
                                    
                                    <th><center>เพิ่มเครดิต</center></th>
                                    <th><center>แก้ไข</center></th>
                                </tr>
                            </thead>
                            <tbody>
                             
            
                                <?php if(!empty($this)): ?>
<?php foreach ($this->user_model->view_users() as $row): ?>
		                     <tr>
                                                <td><center>
<img src="<?= $row['png']?>" width="20" height="20" alt="logo.ico" />
</center></td>
                                                <td><center><?= $row['username'] ?></center></td>
                                                <td><center><?= $row['saldo'] ?></center></td>
                                                <td><center><?php if ($row['is_admin'] == '1' ) { echo '<font color="green">admin</font>';} else { echo '<font color="red">seller</font>'; } ?></center></td>
                                                <td><center><?= $row['created_at']?></center></td>
                                                
                                                
                                                
                                                 
                                                
                                                <td><center>
                                                    
                                                    <a href="/member/userupdateform.php?id=<?= $row['id'] ?>" <span class="fa fa-joomla"></span></a>
                                                </center></td>
                                                <td><center>
                                                    <a href="/member/edit.php?id=<?= $row['id'] ?>" <span class="fa fa-legal"></span></a>
                                                </center></td>
                                             </tr>
                                       <?php endforeach; ?>
                                    <?php else: ?>
                                   
                                        <tr>
                                       <center>     <td class="text-muted text-center" colspan="6"> ไม่มีผู้ใช้</center></td>
                                        </tr>
                                   <?php endif; ?>
                           </center> </tbody>
                        </table>
                      
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
