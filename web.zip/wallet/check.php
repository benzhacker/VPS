<?php 
SESSION_START();
include 'config.php';
$user = $_POST['user'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$passwd = $_POST['passwd'];
$noty_wallet = $_POST['noty_wallet'];
$link = $_POST['link'];
$png = $_POST['png'];
$web = $_POST['web'];
$sql = "select * from users where username='$user'";
$query = mysqli_query($con,$sql);
$result = mysqli_fetch_assoc($query);
if(isset($result)){
$_SESSION['user'] = $result;
include 'input.php';
}else{
echo ' <font color="red">USER wrong</font> ';
}; ?>