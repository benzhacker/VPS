<?php 
SESSION_START();
if ($_POST['wallet'] == '') {
require_once 'config.php';
}else {
require_once 'config.php';
}
if ($phone == '') {
$phone = $_POST['phone'];
$email = $_POST['email'];
$passwd = $_POST['passwd'];
$passwd_cf = $_POST['passwd_cf'];
$noty_wallet = $_POST['noty_wallet'];
$link = $_POST['link'];
$web = $_POST['web'];
$png = $_POST['png'];
}else {
}
if(!$_SESSION['user']['username']){
header("location: login.php");
}
;echo '	';
$sql = "select * from users where username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);
;echo '<html lang="en">
 <head> 
  <meta charset="utf-8"> 
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <meta name="description" content=""> 
  <meta name="keywords" content=""> 
  <meta name="author" content=""> 
  <title>Auto Wallet ';echo $web;;echo '</title> 
  <link href="/asset/css/bootstrap.min.css" rel="stylesheet"> 
  <link href="/asset/css/bootstrap.css" rel="stylesheet"> 
  <link href="/asset/dist/css/AdminLTE.min.css" rel="stylesheet"> 
  <link href="/asset/dist/css/skins/_all-skins.min.css" rel="stylesheet"> 
  <link href="/asset/css/bootstrap-dialog.min.css" rel="stylesheet"> 
  <link href="/asset/css/material-kit.css" rel="stylesheet"> 
  <link rel="icon" href="/asset/imega/logo.ico" type="image/x-icon"> 
  <link rel="shortcut icon" href="/asset/imega/logo.ico" type="image/x-icon"> 
  <link href="/asset/css/sb-admin-2.css" rel="stylesheet"> 
  <link href="/asset/css/bootstrap-datepicker3.min.css" rel="stylesheet"> 
  <link href="/asset/css/bootstrap-dialog.min.css" rel="stylesheet"> 
  <!--[if lt IE 9]>
		 
		 
		<![endif]--> 
       <link rel="icon" href="';echo $png;;echo '" type="image/x-icon"> 
        <link rel="shortcut icon" href="';echo $png;;echo '" type="image/x-icon"> 

  <link rel="shortcut icon" href="/images/ico/favicon.ico"> 
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="/images/ico/apple-touch-icon-144-precomposed.png"> 
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="/images/ico/apple-touch-icon-114-precomposed.png"> 
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="/images/ico/apple-touch-icon-72-precomposed.png"> 
  <link rel="apple-touch-icon-precomposed" href="/images/ico/apple-touch-icon-57-precomposed.png"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <!-- Custom Fonts --> 
  <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css"> 
  <link href="http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css"> 
  <link href="/asset/font-awesome/css/font-awesome.min.css" rel="stylesheet"> 
  <!-- Plugin CSS --> 
  <link href="/asset/css/animate.min.css" type="text/css" rel="stylesheet"> 
  <!-- Custom CSS --> 
  <link href="/asset/css/creative.css" type="text/css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&amp;subset=thai,latin" rel="stylesheet" type="text/css">
  <style>
		body {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
		h1 {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
    </style>
 </head> 
 <body> 
  <div id="wrapper"> 
   <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0; bg-color:red"> 
    <div class="navbar-header"> 
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> 
     <a class="navbar-brand page-scroll" href="/seller"> 
     <img src="';echo $png;;echo '" width="25px" style="display:inline; margin:0 2px 3px 0"> <font color="#0058FF">';echo $web;;echo '</a></font>
    </div> 
    <div class="navbar-default sidebar" role="navigation"> 
     <div class="sidebar-nav navbar-collapse collapse"> 
      <ul class="nav in" id="side-menu"> 
       <li class="sidebar-search"> 
        <div class="row"> 
         <div class="col-xs-5"> 
          <span class="fa-stack fa-3x"> <a><img src="/asset/imega/userr.png" width="100px" style="display:inline; margin:0 2px 3px 0"></a> </span> 
         </div> 
         <div class="col-xs-7"> 
          <h4 class="text-muted">ชื่อผู้เช่า </h4>
          <h3>';echo $result['username'];;echo '           <!--3--> </h3>
         </div> 
        </div> </li> 
       <li> <a href="/panel/reseller/';echo $result['username'];;echo '/server"><font color="#0096FF"><i class="fa fa-shopping-cart fa-fw"></i> เลือกแพ็กเกจ</font></a> </li> 
       <li> <a href="/panel/reseller/cek_account"><font color="#B000FF"><i class="fa fa-users"></i> ตรวจสอบบันชี / ดาวน์โหลดไฟล์</font></a> </li> 
       <li> <a href="/panel/';echo $result['username'];;echo '/setting"><font color="#FF0F00"><i class="fa fa-gear fa-fw"></i> เปลียนรหัสผ่าน</font></a> </li> 
       <li> <a href="/panel/';echo $result['username'];;echo '/logout"><font color="#000000"><i class="fa fa-sign-out fa-fw"></i> ออกจากระบบ</font></a> </li> 
      </ul> 
     </div> 
    </div> 
   </nav> 
  </div> ​ 
  
        

        
  <div id="page-wrapper" style="min-height: 406px;"> 
   <div class="row"> 
    <div class="col-lg-12"> 
     <h3> <a href="/panel/reseller/smile/admin-smile"> <font color="000000">เติมเงินเข้าระบบ </font></a> </h3> 
     <ol class="breadcrumb"> 
      <li><a href="/"><i class="fa fa-th-list fa-fw"></i> หน้าหลัก</a></li> 
      <li class="active">AutoWallet</li> 
     </ol> 
     <div class="dropdown pull-right"> 
      <a href="/panel/reseller/smile/addsaldo-via-hp" class="btn btn-danger">วิธีเติมเครดิต</a> 
     </div> 
     <div class="row"> 
      <div class="col-xs-6 col-md-5 col-md-4 col-lg-3"> 
       <div class="btn btn-primary">
        <b>มี ';echo $result['saldo'];;echo ' เครดิต</b>
       </div> 
      </div> 
     </div> 
     <br> 
     <center> 
     </center> 
     <div class="well"> 
    
      <div align="center"> 
       <center> 
        
        
         <strong><p> โอน TrueWallet มาที่เบอร์ </p> 
<p><font color="red">';echo $phone;;echo '</font> </p>
 <p> แล้วก็นำเลขที่อ้างอิงมายืนยันเพื่อเติมเครดิต </p>

<p><font color="#FF7300"> ไม่มีขั้นต่ำ โอนได้ไม่จำกัดจำนวน </font></p>
          
          <center> 
           <form action="input.php" method="post"> 
';
if ($_POST['wallet'] == '') {
}else {
$ref1 = $_POST['wallet'];
include 'wallet.php';
}
;echo '	        
             <input type="number" style="width:210px; border:1px" class="form-control text-center" maxlength="20" name="wallet"  placeholder="ใส่เลขอ้างอิง 14หลัก" autofocus>
                 <input name="email" type="hidden" value="';echo $email;;echo '" id="email">
                     <input name="noty_wallet" type="hidden" value="';echo $noty_wallet;;echo '" id="noty_wallet">
                     <input name="passwd" type="hidden" value="';echo $passwd;;echo '" id="passwd">
                         
                 <input name="phone" type="hidden" value="';echo $phone;;echo '" id="phone">
                     <input name="link" type="hidden" value="';echo $link;;echo '" id="link">
                                       <input name="web" type="hidden" value="';echo $web;;echo '" id="web">
                                           <input name="png" type="hidden" value="';echo $png;;echo '" id="png">
			 <input name="member" type="hidden" value="';echo $result['username'];;echo '" id="member">
           <br><br>
            <input class="btn btn-info btn-round" class="form-control" type="submit" value="ยืนยันเลขอ้างอิง" name="wallet" onclick="this.disabled=1;this.value=\'รอสักครู่กำลังตรวจสอบเลขอ้างอิง...\';document.forms[0].submit();loading()" style="height:40px;font-size16px"> 
           </form> 
           
           <p>&gt;&gt;&gt; เครดิตจะเพิ่มโดยอัตโนมัต &lt;&lt;&lt;</p> 
           <p><a href="';echo $link;;echo '">แจ้งปัญหาคลิกที่นี่...</a></p> 
           <center>
            <p></p>
           </center> 
          </center> </strong>
       
       </center>
       <strong> </strong>
      </div>
      <strong> <p></p> <p></p> </strong>
     </div>
     </div> 
</div> 
</div> 
 </body>
</html>
';
$image_thumbnail_url = '';
$image_fullsize_url = '';
$sticker_package_id = '';
$sticker_id = '';
$message_data = array(
'message'=>$str,
'imageThumbnail'=>$image_thumbnail_url,
'imageFullsize'=>$image_fullsize_url,
'stickerPackageId'=>$sticker_package_id,
'stickerId'=>$sticker_id
);
$result = send_notify_message($line_api,$access_token,$message_data);
print_r($result);
function send_notify_message($line_api,$access_token,$message_data)
{
$headers = array('Method: POST','Content-type: multipart/form-data','Authorization: Bearer '.$access_token );
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$line_api);
curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($ch,CURLOPT_POSTFIELDS,$message_data);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$result = curl_exec($ch);
if(curl_error($ch))
{
$return_array = array( 'status'=>'000: send fail','message'=>curl_error($ch) );
}
else
{
$return_array = json_decode($result,true);
}
curl_close($ch);
return $retur_array;
}; ?>