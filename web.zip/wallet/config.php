<?php echo '﻿';
define("API_PASSKEY","0657721416");
define("API_URL","http://memoney.online/api_topup/api.php");
include_once '../application/config/database.php';
$host = $db['default']['hostname'];
$user = $db['default']['username'];
$pass = $db['default']['password'];
$db = $db['default']['database'];
$con = new mysqli($host,$user,$pass,$db);
if ($con->connect_error) {
die('เชื่อมต่อไม่ได้ '.$con->connect_error);
}; ?>