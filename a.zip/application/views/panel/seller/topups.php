<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
                      <div class="col-md-6 col-md-6 col-xs-12">
                        <div class="info-box bg-dark"> <span class="info-box-icon"><i class="fa fa-money"></i></span>
                          <div class="info-box-content"> <span class="info-box-number">&#3618;&#3629;&#3604;&#3648;&#3591;&#3636;&#3609;&#3588;&#3591;&#3648;&#3627;&#3621;&#3639;&#3629;</span> <span class="info-box-number">
                              <?= $user -> saldo ?>
                              &#3610;&#3634;&#3607;</span>
                                <div class="progress">
                                  <div class="progress-bar" style="width: 70%"></div>
                                </div>
                            <span class="progress-description"> <i class="ion ion-bag"></i> <a href="<?= base_url('main/'.$_SESSION['username'].'/topup') ?>" class="small-box-footer">&#3648;&#3605;&#3636;&#3617;บัตรทรู <i class="fa fa-arrow-circle-right"></i></a> </span> </div>
                        </div>
                      </div>
		
		

    <!-- Main content -->
    <section class="content">
    <br>
	 <br>
	  <br>
	   <br>
		</center>       
	<div class="row">
        <div class="col-lg-12">
        	<div class="box box-widget widget-user">
        	<div class="box-tools pull-right">
                 <button class="btn btn-xs btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
             </div>
             
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/99.jpg') ?>') center center;">
<h3 class="widget-user-username">เติมเงิน wallet เลขอ้างอิง</h3></label> 
              <h5 class="widget-user-desc"></h5>
              <form action="/topup/input.php" method="post">
			  <input name="user" type="hidden" value="<?php echo  $user->username ?>" id="user">
            </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://f.ptcdn.info/226/056/000/p4cda9342Q97pwxiSI9-o.gif" alt="User Avatar">
            </div>
             <ul class="nav nav-stacked">
			 <li><a href="#"><span style="font-size: 16px;"><B> ชื่อบัญชี Wallet </B><span style="font-size: 16px;" class="pull-right"><B> เบอร์ Wallet </span></a></li>
			 <ul class="nav nav-stacked">
			 <li>
			 <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"> <?php foreach ($this->user_model->view_asset() as $row): ?>
									<?php if (!empty($row['pemilik'])): ?>
									<span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $row['pemilik']?></span><br> 
									<?php endif; ?>					
			  					 <?php endforeach; ?> </span><span style="font-size: 16px;" class="pull-right badge bg-orange"> <?php foreach ($this->user_model->view_asset() as $row): ?>
									<?php if (!empty($row['nohp'])): ?>
									<span style="font-size: 16px;" class="badge bg-orange"><?php echo  $row['nohp']?></span><br> 
									<?php endif; ?>					
			  					 <?php endforeach; ?> </span></a></li>
								 
								  <img src="http://139.59.120.41:85/topup/howto-wallet.png" width="100%" height="374" />
									
             
			 <div class="box-body">
                    <table class="table">
                        <tr>
					
					
						<input  style="text-align: left" name="wallet" type="number" class="form-control" value="" readonly="" " placeholder=" กดปุ่มด้านล่างนี้ หากเข้าใจแล้ว" required>  
					</div>			
			        
        </div>
			  <button type="submit" class="btn btn-success btn-block btn-main btn-round" >รับโค๊ดเติมเงิน อัติโนมัติ</button>
             </form>
		</div>      
       
	</div>                
 </section>  
</div>
  <!-- /.content-wrapper -->