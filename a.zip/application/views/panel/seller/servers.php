<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
  <section class="content-header">
  	                   <div class="row">
            <div class="col-lg-6">
                        <div class="info-box bg-dark"> <span class="info-box-icon"><i class="fa fa-money"></i></span>
                            <div class="info-box-content"> <span class="info-box-number">&#3618;&#3629;&#3604;&#3648;&#3591;&#3636;&#3609;&#3588;&#3591;&#3648;&#3627;&#3621;&#3639;&#3629;</span> <span class="info-box-number">
                              <?= $user -> saldo ?>
                              &#3610;&#3634;&#3607;</span>
                                <div class="progress">
                                  <div class="progress-bar" style="width: 70%"></div>
                                </div>
					<button style="font-size: 16px;" class="btn-danger" type="button" data-toggle="dropdown"><span class="ion ion-bag"></span> เติมเงิน </button>
				<ul class="dropdown-menu"><li class="active"><a href="<?= base_url('main/'.$_SESSION['username'].'/topups') ?>">เติม wallet เลขอ้างอิง</a></li>					
				<li><a href="<?= base_url('main/'.$_SESSION['username'].'/topup') ?>">เติมบัตรทรูมันนี้</a></li>
				</ul>
                        </div>
                      </div>
					  					  
					    </section>
<section class="content">
    		 
                    <div class="col-sm-6 col-md-6 col-lg-6">
                
              </div>	  
             <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6">
                <?php if (isset($message)) {echo $message; }?>
            
		</div>
        <?php foreach($server as $row): ?>
		
       <div class="col-sm-6 col-md-6 col-lg-6">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/99.jpg') ?>') center center;"><span style="font-size: 13px;"  class="pull-right btn-danger"> <marquee scrollamount="2"><?php if ($row['Status']) { echo '';} else {echo "เซิร์ฟเวอร์เต็ม";}?></marquee></span>
              <h3 class="widget-user-username"><B><?php echo  $row['ServerName']?><B></h3>
              <h4 class="widget-user-desc"><B><?php echo  $row['Expired']?> วัน <?php echo  $row['Price']?> บาท <B></h4>
          </div>
            <div class="widget-user-image">
              <img src="http://www.เฮียเบิร์ด.com/all-img/anm1.gif" alt="User Avatar" class="img-circle">            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">รายละเอียดเซิร์ฟเวอร์</span></span>
         </div>
         
              <ul class="nav nav-stacked">
                <li><a href="#"><B> เซิร์ฟเวอร์ </B><span class="pull-right">IP HOST</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-aqua"><?php echo  $row['Location']?></span> <span style="font-size: 16px;" class="pull-right badge bg-purple">แสดงเมื่อเช่าแล้ว</span></a></li>
                
                <li><a href="#"> PORT <span class="pull-right">จำกัดการเชื่อมต่อ</span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-maroon"><?php echo  $row['OpenSSH']?>, <?php echo  $row['Dropbear']?></span><span style="font-size: 16px;" class="pull-right badge bg-navy"> VPN <?php echo  $row['limitvpn']?> เครื่อง <!--?php echo  $row['limitssh']?--></span></a></li>
                
                <li><a href="#"> วันใช้งาน <span class="pull-right"> จำกัด </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-purple"><?php echo  $row['Expired']?> วัน </span><span style="font-size: 16px;" class="pull-right badge bg-blue">รองรับ <?php echo  $row['MaxUser']?> คน </span></a></li>
                
                <li><a href="#"> ราคา <span class="pull-right"> สถานะเซิร์ฟ </span></a></li>
                <li><a href="#"><span style="font-size: 16px;" class="badge bg-green"><?php echo  $row['Price']?> บาท </span><span style="font-size: 16px;" class="pull-right badge bg-orange"> <?php if ($row['Status']) { echo 'ยังคงเช่าได้';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span></a></li>
                
              </ul>
          </div>
						 
                    <div class="box-footer text-center">
                    	<button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#<?php echo  $row['Id']?>"><i class="fa fa-shopping-cart"></i>
  เช่าเซิร์ฟเวอร์
						</button>
                        
                        <a href="<?php echo  base_url('web/vpn/'.str_replace(' ','-',$row['configvpn']).' ') ?>" class="btn btn-sm btn-warning"><i class="fa fa-cloud-download"></i> โหลดไฟล์ VPN</a>
                        <!---a href="<?php echo  base_url('web/http/'.str_replace(' ','-',$row['configssh']).' ') ?>" class="btn btn-sm btn-info"><i class="fa fa-cloud-upload"></i>???? SSH</a-->
                    </div>
                                        
<div class="modal fade" id="<?php echo  $row['Id']?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">ข้อครวจำ!!!</h4>
      </div>
      <div class="modal-body">
        ไฟล์ VPN สามารถต่อได้ 1 เครื่องต่อไฟล์ กรุณาใช้ไฟล์ให้ถูกการใช้งาน เพื่อไม่ให้ส่งผลกระทบต่อลูกค้าท่านอื่น ถ้าพบเห็นการใช้งานที่ผิดปกติแอดมินสามารถระงับการใช้งาน ได้โดยไม่แจ้งล่วงหน้าครับผม
      </div>
      <div class="modal-footer">
        <a href="<?php echo  base_url('main/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-info"><i class="fa fa-shopping-cart fa-fw"></i>ยืนยันการเช่า</a>
        <button type="button" class="btn btn-danger btn-simple" data-dismiss="modal">ยกเลิก</button>
      </div>
    </div>
  </div>
</div>
                    
                    
                    
         </div>
          </div>
        <?php endforeach; ?>
    </div>     
    </section>
</div>