<?php
mysql_select_db('ssh',mysql_connect('localhost','root','038451962'))or die(mysql_error());
?>