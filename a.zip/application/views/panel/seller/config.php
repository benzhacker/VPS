<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      </h1>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i>หน้าหลัก</a></li>
        <li class="active">CONFIG VPN</li>
    </ol>
    </section>

						<br><!---div class="row">
                    <div class="col-md-2 text-center">
                        <label class="label label-success">Fast Data Transfer</label>
                        <label class="label label-warning">High Speed Servers</label>
                        <label class="label label-info">Hide Your IP</label>
                        <label class="label label-primary">Premium VPN Server</label>
                        <label class="label label-warning">Worldwide Servers</label>
                        <label class="label label-success">Internet Privacy</label>
                        <label class="label label-info">Exclusive Secure Shell</label>
                        <label class="label label-success">Security Solutions</label>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <label class="label label-danger">No DDOS</label>
                        <label class="label label-danger">No Hacking</label>
                        <label class="label label-danger">No Carding</label>
                        <label class="label label-danger">No Spamm</label>
                        <label class="label label-danger">No Torrent</label>
                        <label class="label label-danger">No Fraud</label>
                        <label class="label label-danger">No Repost</label>                        
                    </div>
                </div>
			    <p></p---->

    <!-- Main content -->
    
  <section class="content">   
       <div class="col-sm-6 col-md-4 col-lg-12">    
        <div class="box box-widget widget-user">
           <div class="widget-user-header bg-black" style="background: url('<?php echo  base_url('asset/img/99.jpg') ?>') center center;">
              <h3 class="widget-user-username"><B><B></h3>
			  <center><span class="description-text"><span style="font-size: 16px;"  class="badge bg-warning">CONFIG OPENVPN</span></center>
              <h4 class="widget-user-desc"><B><B></h4>
              <p>     </p>
          </div>
            <div class="widget-user-image">
              <img class="img-circle" src="https://media.giphy.com/media/LaBqWk4qnYxd6/giphy.gif" alt="User Avatar">
            </div>
                  
       <div class="box-footer no-padding">
      	<div class="description-block"><br><br>
            <span class="description-text"><span style="font-size: 16px;"  class="badge bg-red">โหลดไฟล์ VPN</span></span>
         </div>
         
          <ul class="nav nav-stacked">
              <div class="panel-body"></div>
        			</ul>
		  </div>
         </div>
 		
 
       </section>      
  </div>