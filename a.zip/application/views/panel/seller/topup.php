
<?php defined('BASEPATH') OR exit('No direct script access allowed');
 
?>
 <div class="content-wrapper">
 <div class="col-md-6 col-md-6 col-xs-12">
 <div class="info-box bg-dark"> <span class="info-box-icon"><i class="fa fa-money"></i></span>
 <div class="info-box-content"> <span class="info-box-number">&#3618;
&#3629;
&#3604;
&#3648;
&#3591;
&#3636;
&#3609;
&#3588;
&#3591;
&#3648;
&#3627;
&#3621;
&#3639;
&#3629;
</span> <span class="info-box-number">
 
<?php echo $user -> saldo 
?>
 &#3610;
&#3634;
&#3607;
</span>
 <div class="progress">
 <div class="progress-bar" style="width: 70%"></div>
 </div>
 <span class="progress-description"> <i class="ion ion-bag"></i> <a href="
<?php echo base_url('main/'.$_SESSION['username'].'/topups') 
?>" class="small-box-footer">&#3648;
&#3605;
&#3636;
&#3617;
&#3648;
&#3591;
&#3636;
&#3609;
 <i class="fa fa-arrow-circle-right"></i></a> </span> </div>
 </div>
 </div>
 <p></p>
<br />
<br />
<br />
 <!-- Main content -->
 <section class="content">
 <div class="row">
 <div class="col-lg-12">
 	<div class="box box-widget widget-user">
 	<div class="box-tools pull-right">
 <button class="btn btn-xs btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
 </div>
 
 <div class="widget-user-header bg-black" style="background: url('
<?php echo base_url('asset/img/99.jpg') 
?>') center center;
">
 <h3 class="widget-user-username">TRUE MONEY (บัตรทรูมันนี่)</h3>
 <h5 class="widget-user-desc"></h5>
 
 </div>
 <div class="widget-user-image">
 <img class="img-circle" src="https://www.fingo.co.za/wp-content/uploads/2017/07/fin-payment-icon.gif" alt="User Avatar">
 </div>
 
 <div class="box-body">
 <table class="table">
 <tr>
						<br> <center><img src="
<?php echo base_url('asset/img/tmoney.png') 
?>"><br></center> <br>
								 <center><h5> เติมผ่านบริการ true money มีค่าทำเนียม 14% ตัวอย่าง เติม 50 บาท จะได้ 43 บาท <h5></center>
					<div class="form-group">
						<label for="tmn_password">บัตรเงินสดทรูมันนี่</label>
						<input name="tmn_password" type="number" id="tmn_password" maxlength="14" class="form-control" placeholder="กรอกบัตรทรูมันนี่ 14 หลัก">
				 <input name="ref1" type="hidden" value="
<?php echo $user->id 
?>" id="ref1">
				 <input name="ref2" type="hidden" value="
<?php echo $user->username 
?>" id="ref2">
				 <input name="ref2" type="hidden" value="
<?php echo $user->email 
?>" id="ref2"> 
					</div>				
					<button type="button" class="btn btn-success btn-block btn-main" onclick="submit_tmnc()">ยืนยัน</button>
					 <label class="label label-danger" style="font-size: 11px;
">ขณะเติมเงินโปรดรอ อย่ารีเฟรชหรือปิดหน้าจอน่ะครับ</label>
								 
					 </tr>
 </table>
 		 </div> 
 	</div>
 </div>
 
 
	</div> 
 </section> 
</div>

<!-- แก้ไขตรง UID เพื่อเปลี่ยนเป็น UID Tmtopup ของท่านเอง -->
<script type="text/javascript" src='https://www.tmtopup.com/topup/3rdTopup.php?uid=623'></script>

 <!-- /.content-wrapper -->