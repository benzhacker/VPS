<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
		<title>MEMBER - VPN : บริการอินเตอร์ openvpn</title>
		<!-- core CSS -->
		
		<link rel="stylesheet" href="http://เฮียเบิร์ด.com/all-img/asset/css/bootstrap.min.css">
        <link rel="stylesheet" href="http://เฮียเบิร์ด.com/all-img/asset/font-awesome/font-awesome.min.css">
		<link href="http://เฮียเบิร์ด.com/all-img/asset/css/sb-admin-2.css" rel="stylesheet"/>
		<link href="http://เฮียเบิร์ด.com/all-img/asset/css/bootstrap-datepicker3.min.css" rel="stylesheet"/>
		<link href="http://เฮียเบิร์ด.com/all-img/asset/css/bootstrap-dialog.min.css" rel="stylesheet"/>
		<link href="http://เฮียเบิร์ด.com/all-img/ajax/metisMenu.min.css">
		<script src="http://เฮียเบิร์ด.com/all-img/js/jquery.js"></script>

		<link href="SHORTCUT ICON" HREF="http://เฮียเบิร์ด.com/all-img/birdlogo.png"
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #FFFFFF;
}
-->
</style></head>
	<body>
<html lang="en" style="height: auto;">
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<meta name="author" content="">
		<title>MEMBER VPN</title>
		
<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="http://เฮียเบิร์ด.com/all-img/asset/font-awesome/font-awesome.min.css" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="http://เฮียเบิร์ด.com/all-img/asset/css/animate.min.css" type="text/css" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="http://เฮียเบิร์ด.com/all-img/asset/css/creative.css" type="text/css" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="http://เฮียเบิร์ด.com/all-img/asset/ajax/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
	
		
       
	<LINK REL="SHORTCUT ICON" HREF="http://เฮียเบิร์ด.com/all-img/asset/img/logobird.png"

		
	</head>
	
	
	<body class="skin-black-light fixed sidebar-mini" id="page-top" style="height: auto;">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="MEMBER - VPN">
<meta name="author" content="MEMBER - VPN">
<link rel="stylesheet" href="http://103.86.49.122/signup/css/bootstrap.min.css" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="http://103.86.49.122/signup/font-awesome/css/font-awesome.min.css" type="text/css">

<link rel="stylesheet" href="http://103.86.49.122/signup/css/animate.min.css" type="text/css">

<link rel="stylesheet" href="http://103.86.49.122/signup/css/creative.css" type="text/css">


<nav id="mainNav" class="navbar navbar-default bg-dark navbar-fixed-top affix-top">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand page-scroll" href="/">
<img src="http://เฮียเบิร์ด.com/all-img/logobird.png" width="25px" style="display:inline; margin:0 2px 3px 0"> MEMBER VPN</a>
</div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right">
<li>
<a class="page-scroll" href="/login/login"> เข้าสู่ระบบสมาชิก </a></li>
<li>
<a class="page-scroll" href="https://m.facebook.com/ceolnw">ติดต่อแอดมิน</a>
</li>
</ul>
</div>
</div>
</nav><br><br><br>
<section id="services">
<div class="container">
<div class="row">
<div class="col-lg-12 text-center">
<br>
<img class="img-circle" src="https://cdn-images-1.medium.com/max/1600/1*Jj799s3EEUwg_FuN_VGWQQ.gif" width="240" height="240"><br>
<h4><b>M E M B E R  V P N </b></h4>
<h4><b> WELLCOME TO THAILAND </b></h4><br>
</div>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="col-md-12">
				<?php if (validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  validation_errors() ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if (isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo  $error ?>
				</div>
			</div>
		<?php endif; ?>
		
  <?php echo  form_open() ?>
  <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input required="required" id="username" type="text" class="form-control" onBlur="checkText();" name="username" value="" placeholder="ใส่ไอดี ของคุณ" minlength="3">
</div>
  <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
<input required="required" id="Email" type="email" class="form-control" onBlur="checkText();" name="email" value="" placeholder="ใส่อีเมล์ ของคุณ" minlength="3">
</div>
  <div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-retweet"></i></span>
<input required="required" id="password" type="password" class="form-control" onBlur="checkText();" name="password" value="" placeholder="ใส่รหัสผ่านอย่างน้อย 6 ตัว" minlength="3">
</div>
<div style="margin-bottom: 25px" class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input required="required" id="password_confirm" type="password" class="form-control" onBlur="checkText();" name="password_confirm" value="" placeholder="ใส่รหัสผ่านอีกครั้ง" minlength="3">
</div>
  <div class="form-group">
    <button class="btn btn btn-success btn-block" type="submit"><i class="fa fa fa-check-square-o"></i> ยืนยันการสมัคร</button>
    <div class="form-group"></div>
   
    <b>
    <center>
  </div>
  </form>


</body>
</html>