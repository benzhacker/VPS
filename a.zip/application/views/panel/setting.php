<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 <div class="content-wrapper">
 <div class="col-md-6 col-md-6 col-xs-12">
                        <div class="info-box bg-info"> <span class="info-box-icon"><i class="fa fa-user"></i></span>
                            <div class="info-box-content"> <span class="info-box-number">ID ACCOUNT &raquo; <span style="font-size: 16px;" class="info-box-number pull-right badge bg-green">
                              <?php echo $_SESSION['username'] ?>
                              </span></span> <span class="info-box-number">USERNAME &raquo; <span style="font-size: 16px;" class="info-box-number pull-right badge bg-blue">
                                <?php echo $_SESSION['username'] ?>
                                </span></span>
                              <div class="progress">
                                <div class="progress-bar" style="width: 0%"></div>
                              </div>
                              <span class="progress-description"> <i class="ion ion-stats-bars"></i> <a href="<?php echo base_url('main/'.$_SESSION['username'].'/profile
') ?>" class="small-box-footer">&#3648;&#3614;&#3636;&#3656;&#3617;&#3648;&#3605;&#3636;&#3617; <i class="fa fa-arrow-circle-right"></i></a> </span> </div>
                        </div>         
     <br />
	
   <section class="content-header"></section>
   <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">เปลี่ยนรหัสผ่านบัญชีใหม่</h3>
          </div>
            <!-- /.box-header -->
            <!-- form start -->
        <div class="row">
        <div class="col-md-6">
			<?php if (isset($message)) {echo $message; }?>
			<?php if (isset($success)) {echo $success; }?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> &#3648;&#3611;&#3621;&#3637;&#3656;&#3618;&#3609;&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;
                </div>
                <div class="panel-body">
                    <form role="form" action="<?= base_url('main/'.$_SESSION['username'].'/setting')?>" method="POST">
						<input type="hidden" name="username" value="<?= $_SESSION['username'] ?>">
                        <div class="form-group">
                            <label>&#3619;&#3627;&#3633;&#3626;&#3612;&#3656;&#3634;&#3609;&#3648;&#3604;&#3636;&#3617;</label>
                            <input class="form-control" placeholder="Old Password" name="oldpass" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่</label>
                            <input class="form-control" placeholder="ใส่-รหัสผ่านใหม่" name="password" type="password" required>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านใหม่อีกครั้ง</label>
                            <input class="form-control" placeholder="ใส่-รหัสผ่านใหม่อีกครั้ง" name="passconf" type="password" required>
                        </div>
                        <button type="button" class="btn btn-danger form-control" data-toggle="modal" data-target="#modal-danger">เปลี่ยนรหัสผ่าน</button>
						<div class="modal modal-danger fade" id="modal-danger">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">แจ้งเตือนการเปลี่ยนรหัสผ่าน</h4>
</div>
<div class="modal-body">
<p>กรุณาเช็ครหัสก่อนที่จะกดยืนยัน</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-outline pull-left" data-dismiss="modal">ยกเลิก</button>
<button type="submit" class="btn btn-outline">ยืนยัน</button>
</div>
</div>

</div>

</div>

</form> 
<div class="box-footer">
</div>
</div>

                    </form>
          </div>
          </div>
        </div>
      </div>
</div>   

                          <div class="box-footer">
                       </div>
                  </div>         
	        	</div>
        </div>
    </section>
  </div>