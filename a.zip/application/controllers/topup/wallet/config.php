<?php
$host = 'localhost';
$user = 'root';
$pass = '123456789'; //ใส่รหัสครับ phpmyadmin
$db = 'OCS_PANEL';
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);


$walletmoney = $_POST['wallet'];

ini_set('display_errors', 1);
include_once('manager/TrueWallet.php');
$wallet = new TrueWallet();

//ใส่ชื่อรหัส wallet ของคุณ
$username = "wallet@email";
$password = "123456789";

$wallet->logout();
