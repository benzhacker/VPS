<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
<div class="row"> 
    <div class="col-lg-12"> 
          <section class="content-header">
      <h2>
       เติมเงินเข้าระบบ
      </h2>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">โอนผ่านธนาคาร</li>
    </ol>
    </section>
     <div class="dropdown pull-right"> 
      <a href="http://m.me/kariya00" class="btn btn-danger"><span class="fa fa-bullhorn fa-fw"></span> ส่งหลักฐาน</a> 
     </div> 
     <div class="row"> 
      <div class="col-xs-6 col-md-5 col-md-4 col-lg-3"> 
       <div class="btn btn-primary">
        เครดิต : 
        <b><?= $user -> saldo ?></b>
       </div> 
      </div> 
     </div> 
     <p>&nbsp;</p> 
     <div class="col-sm-6">
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?php if (isset($message)) : ?>
					<div class="col-md-12">
						<div class="alert alert-success" role="alert"><?= $message ?></div>
					</div>
					<?php endif;?>
			   <?= form_open() ?>
     <div class="well"> 
      <p> </p>
      <div align="center"> 
       <center> 
           <?php foreach ($this->user_model->view_asset() as $row): ?>
					<?php if (!empty($row['nohp'])): ?>
           <p><span class="label label-primary"><?= $row['provider']?> </span></p> 
        <p><a href="https://m.me/GengPichet"><?= $row['nohp']?></a></p> 
        <p>ชื่อบัญชี <?= $row['pemilik']?></p>
        <?php endif; ?>	
			   <?php endforeach; ?>
        
        <p><span class="label label-danger">หมายเหตุ</span></p> 
        <font color="#ff0000">หลังจากแจ้งโอนโปรดส่งหลักฐานกานโอนด้วยครับ</font>
          <p></p>
          
          <center>
           <label for="sender">หมายเลขบัญชี</label>
          </center>
          <p> <input type="number" name="sender" class="form-control text-center" style="width:250px; border:5px" id="sender" placeholder="xxxxxxxxxx"> </p>
          <center>
           <small class="text-muted">สำหรับหลักฐานการจ่ายเงินแล้ว</small>
          </center> 
         </div> 
         <div class="form-group"> 
             <h4> </h4>
          <center>
           <div class="form-group">
						<label for="hp">เลือกบัญชีปลายทางที่โอน</label>
						<select name="hp" id="hp" style="width:250px; border:5px" class="form-control text-center">
							<?php foreach ($this->user_model->view_asset() as $row): ?>
							<?php if (!empty($row['nohp'])): ?>
							<option value="<?= $row['nohp']?>"><?= $row['nohp'].' ('.$row['provider'].')'?></option>
							<?php endif;?>
							<?php endforeach; ?>
						</select>
					</div>
          </center> 
         <div class="form-group"> 
          <center>
           <label for="hp">จำนวนเงินที่โอน</label>
          </center> 
          <input type="number" style="width:250px; border:5px" name="jumlah" class="form-control text-center" id="jumlah" value="50"> 
          <center>
           <small class="text-muted">ราคาเซิฟขันต่ำ 50 บาท</small>
          </center> 
         </div> 
         <div class="form-group"> 
          <input type="submit" class="btn btn-danger form-control" style="width:250px; border:5px" value="ยืนยัน"> 
         </div> 
        </form> 
        <center>
         <p></p>
        </center> 
       </center> 
      </div> 
      <p></p> 
      <p></p> 
     </div> 
    </div> 
   </div> 
   <div class="row"> 
    <div class="col-sm-6"></div> 
   </div> 
  </div> 
  <br> 
  <footer id="site-footer" role="contentinfo"> 
  </footer>
  <!-- #site-footer --> 
  <!-- js --> 