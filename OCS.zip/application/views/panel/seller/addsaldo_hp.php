<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
	 <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">เติมเงิน & แจ้งโอนเงิน</h1>
            <div class="well">ยอดเงินคงเหลือ : <B><?php if (isset($user->saldo)) {echo $user->saldo; }?></B> บาท</div>
        </div>
    </div>
				  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?php if (isset($message)) : ?>
					<div class="col-md-12">
						<div class="alert alert-success" role="alert"><?= $message ?></div>
					</div>
					<?php endif;?>
			   <?= form_open() ?>
    <div class="form-group">
						<div class="py-5"><div class="container"><div class="row">
						<div class="py-5"><div class="container"><div class="row"><div class="col-md-12"><p class="lead"></p></div></div></div></div>
						<label for="sender">แจ้งโอนเงิน ( วัน=เวลา )</label>
						<input type="text" name="sender" class="form-control" id="sender" placeholder="09/09/60=19.19"/>
						<small class="text-muted">ตัวอย่าง 09/09/60=19.19</small>
					</div>
					<div class="form-group">
						<label for="hp">โอนเข้าช่องทาง</label>
						<select name="hp" id="hp" class="form-control">
							<?php foreach ($this->user_model->view_asset() as $row): ?>
							<?php if (!empty($row['nohp'])): ?>
							<option value="<?= $row['nohp']?>"><?= $row['nohp'].' ('.$row['provider'].')'?></option>
							<?php endif;?>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<label for="hp">จำนวนที่เติม</label>
						<input type="number" name="jumlah" class="form-control" id="jumlah" value="10"/>
						<small class="text-muted">จำนวนเงินเติมต่ำสุดคือ 10 บาท</small>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary form-control" value="แจ้งโอนเงิน"/>
					</div>
			   </form>
            </div>
    </div>
</div>
