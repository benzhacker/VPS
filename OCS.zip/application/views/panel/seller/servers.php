<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">รายชื่อเซิร์ฟเวอร์ VPN,SSH</h1>
 <div class="row">
       <div class="col-xs-12">
           <div class="well well-sm" style="background:#ffd400;color:#fff;">
<table style="width:100%;">
            <tr>
                <td >
		                      ยอดเงินคงเหลือ : <B><?= $user -> saldo ?></B> บาท</td>
                   <td style="text-align: right;">
                   <a href="<?= base_url('panel/reseller/'.str_replace(' ','-',$_SESSION['username']).'/addsaldo-via-hp') ?>" class="btn btn-danger" ><i class="fa fa-plus fa-fw"></i> เพิ่มเครดิต</a>
				 </td>
             </tr>
</table>
 </div>
        </div>
    </div>

    <div class="row">
            <div class="col-lg-12">
                <div align="center">
                  <p>
                                        <img src="http://nugetserver.net/gfx/logo.png" width="153" height="97" /></p>
                  <div class="bs-example">
                    <div class="panel-group" id="accordion">
                      <div class="panel Panel Content">
                        <div class="panel-heading">
                    <table class="table">
                        <tr class="info">
                          <h1 class="panel-title"><strong>ข่าวสาร&amp;โปรโมชั่น
						  </strong></h1>
                          <form action="chek.php" method="post" name="form1" id="form1">
                            <p>
                              <label for="username"></label>
                            </p>
                            <p>
                              <label for="password"></label>
                               ฟรี Server TH,SG,US 1 วัน แรงๆ
                            </p>
                            <p><FONT COLOR="#FF0000">โ</FONT><FONT COLOR="#FF1900">ป</FONT><FONT COLOR="#FF3200">ร</FONT><FONT COLOR="#FF4B00">โ</FONT><FONT COLOR="#FF6400">ม</FONT><FONT COLOR="#FF7D00">ช</FONT><FONT COLOR="#FF9600">ั</FONT><FONT COLOR="#FFAF00">่</FONT><FONT COLOR="#FFC800">น</FONT><FONT COLOR="#FFE100"> </FONT><FONT COLOR="#FFFA00">เ</FONT><FONT COLOR="#FFff00">ต</FONT><FONT COLOR="#E6ff00">ิ</FONT><FONT COLOR="#CDff00">ม</FONT><FONT COLOR="#B4ff00">เ</FONT><FONT COLOR="#9Bff00">ง</FONT><FONT COLOR="#82ff00">ิ</FONT><FONT COLOR="#69ff00">น</FONT><FONT COLOR="#50ff00"> </FONT><FONT COLOR="#37ff00">5</FONT><FONT COLOR="#1Eff00">0</FONT><FONT COLOR="#05ff00"> </FONT><FONT COLOR="#00ff00">บ</FONT><FONT COLOR="#00ff19">า</FONT><FONT COLOR="#00ff32">ท</FONT><FONT COLOR="#00ff4B">ข</FONT><FONT COLOR="#00ff64">ึ</FONT><FONT COLOR="#00ff7D">้</FONT><FONT COLOR="#00ff96">น</FONT><FONT COLOR="#00ffAF">ไ</FONT><FONT COLOR="#00ffC8">ป</FONT><FONT COLOR="#00ffE1"> </FONT><FONT COLOR="#00ffFA">X</FONT><FONT COLOR="#00ffff">2</FONT><FONT COLOR="#00FAff"> </FONT><FONT COLOR="#00E1ff">ถ</FONT><FONT COLOR="#00C8ff">ึ</FONT><FONT COLOR="#00AFff">ง</FONT><FONT COLOR="#0096ff">ว</FONT><FONT COLOR="#007Dff">ั</FONT><FONT COLOR="#0064ff">น</FONT><FONT COLOR="#004Bff">ท</FONT><FONT COLOR="#0032ff">ี</FONT><FONT COLOR="#0019ff">่</FONT><FONT COLOR="#0000ff"> </FONT><FONT COLOR="#0500ff">3</FONT><FONT COLOR="#1E00ff">1</FONT><FONT COLOR="#3700ff">/</FONT><FONT COLOR="#5000ff">3</FONT><FONT COLOR="#6900ff">/</FONT><FONT COLOR="#8200ff">2</FONT><FONT COLOR="#9B00ff">0</FONT><FONT COLOR="#B400ff">1</FONT><FONT COLOR="#CD00ff">8</FONT><FONT COLOR="#E600ff"> </FONT><FONT COLOR="#FF00ff">เ</FONT><FONT COLOR="#FF00FA">ท</FONT><FONT COLOR="#FF00E1">่</FONT><FONT COLOR="#FF00C8">า</FONT><FONT COLOR="#FF00AF">น</FONT><FONT COLOR="#FF0096">ั</FONT><FONT COLOR="#FF007D">้</FONT><FONT COLOR="#FF0064">น</FONT>
							<div class="tab-pane" id="tab_3-2">
                            <FONT COLOR="#FF0000">เติมเงินไม่เข้าแจ้ง เบอร์ Wallet และ Username จำนวนเงิน แจ้งที่ </FONT>
                            <a href="https://www.facebook.com/MMTVPN/" class="btn btn-info"><i class="fa fa-facebook"></i> FACEBOOK </a>
</div>
                            <p>&nbsp;</p>
                          </form>
                          <h4 class="panel-title"><br />
                          </h4>
                        </div>
                      </div>
					  </tr>
					  </table>
                    </div>
                  </div>
                  <p>&nbsp;</p>
                </div>
            </div>

    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) {echo $message; }?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <center><b><i class="d-block mx-auto fa fa-lg fa-server"></i>&nbsp; &nbsp;<?= $row['ServerName']?> &nbsp; <i class="fa fa-rocket fa-lg"></i><?php if ($row['Status']) { echo '';} else {echo " <br /> <br /> ( ปิดการเช่า เซิร์ฟเวอร์เต็ม )";}?></b>
                    </div>
                    <table class="table">
                        <tr>
                            <td>ประเทศ</td><td><span class="label label-primary"><?= $row['Location']?></span></b></td>
                        </tr>
                        <tr>
                            <td>IP</td><td><span class="label label-info"> ท่านยังไม่ได้เช่า</span></b></td>
                        </tr>
                        <tr>
                            <td>MaxUser</td><td><span class="label label-success"><?= $row['MaxUser']?></span><td>User</td></b></td>
                        </tr>
                        <tr>
                            <td>อายุการใช้งาน</td><td><span class="label label-danger"><?= $row['Expired']?></span><td>วัน</td></b></td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td><span class="label label-warning"><?= $row['Price']?></span><td>บาท</td></b></td>
                        </tr>
                    </table>
                    <div class="panel-footer text-center">
						<center>
					<br /> 
                        <a href="<?= base_url('panel/seller/'.$_SESSION['username'].'/buy/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id']) ?>" class="btn btn-success"><i class="fa d-inline fa-lg fa-user-plus"></i> เช่าทันที</a>
					<br /> 
					<br /> 
						<a href="http://<?= $row['HostName']?>:81/MMT-VPN_TRUE.ovpn" class="btn btn-danger"><i class="fa d-inline fa-lg fa-download"></i> TRUE <b>VPN</b></a>
						<a href="http://<?= $row['HostName']?>:81/MMT-VPN_DTAC.ovpn" class="btn btn-primary"><i class="fa d-inline fa-lg fa-download"></i> DTAC <b>VPN</b></a>
						</center>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>