<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
            <h4 class="page-header"><i class="fa fa-phone"></i> บัญชี</h4>
        </div>
    </div>
    <div class="row">
           <div class="col-xs-6">
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
					<div class="form-group">
						<label for="pemilik">ชื่อ - นามสกุล</label>
						<input type="text" name="pemilik" class="form-control" id="pemilik" placeholder="Amonthep Rattanapatima"/>
					</div>
					<div class="form-group">
						<label for="nohp">เบอร์โทร</label>
						<input type="text" name="nohp" class="form-control" id="nohp" placeholder="0946255482"/>
					</div>
					<div class="form-group">
						<label for="provider">ช่องทาง</label>
						<select name="provider" class="form-control">
							<option value="TrueWallet,Airpay,PromptPay">ทรูวอเรท,แอร์เพย์,พร้อมเพย์</option>
							<option value="Airpay">แอร์เพย์</option>
							<option value="PromptPay">พร้อมเพย์</option>
						</select>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary form-control" value="เพิ่มบัญชี"/>
					</div>
			   </form>
		   </div>
		  <div class="col-xs-6">
				<?php if (!empty($asset)):?>
					<h4>บัญชีของคุณ</h4>
					<div class="table-responsive"><table class="table table-hover">
						<thead>
							<tr><th>#</th><th>ชื่อ</th><th>เบอร์โทร</th><th>ช่อทาง</th></tr>
                        </thead>
                        <tbody>
						<?php foreach ($asset as $row): ?>
							<tr>
									<?php if (empty($row['rekening'])):?>
									<td><a href="<?=base_url('admin/del_hp/'.$row['id'])?>">ลบ</a></td>
									<td><?= $row['pemilik'] ?></td>
									<td><?= $row['nohp']?></td>
									<td><?= $row['provider']?></td>
									<?php endif; ?>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table></div>
					<?php else: ?>
						<h4 class="page-header">คุณยังไม่ได้เพิ่มหมายเลขโทรศัพท์ใด ๆ</h4>
				<?php endif; ?>
			</div>
   
    </div>
</div>
