<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <center><h2 class="page-header">เซิร์ฟเวอร์ทั้งหมด</h2></center>
				<?php if (isset($_SESSION['is_admin'])): ?>
                <a href="<?= base_url('panel/administrator/'.str_replace(' ','-',$_SESSION['username']).'/addserver') ?>" class="btn btn-default pull-right"><i class="fa fa-plus fa-fw"></i> เพิ่มเซิร์ฟเวอร์</a>
                <?php endif; ?>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12">
                <?php if (isset($message)) { echo $message;} ?>
            </div>
        <?php foreach($server as $row): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-default">
					 
                    <div class="panel-heading">
                       
							<center><div class="panel-title"><b><i class="d-block mx-auto fa fa-2x fa-server"></i>&nbsp; &nbsp;<?= $row['ServerName']?></b></div></center>
							<span clas="pull-right">
							<?php if ($row['Status']): ?>
								<a class="btn btn-success btn-sm pull-right" href="<?= base_url('panel/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/lock' ) ?>"><i class="fa fa-unlock"></i> ปิดรับสมัคร</a>
								<?php else: ?>
								<a class="btn btn-danger btn-sm pull-right" href="<?= base_url('panel/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/unlock' ) ?>"><i class="fa fa-lock"></i>  เปิดรับสมัคร</a>
								<?php endif; ?>
							</span>
                    </div>
                    <div class="panel-body">
                    <table class="table table-condensed">
                        <tr>
                            <td>ประเทศ</td><td><?= $row['Location']?></td>
                        </tr>
                        <tr>
                            <td>ไอพี</td><td><?= $row['HostName']?></td>
                        </tr>
                        <tr>
                            <td>ราคา</td><td><?= $row['Price']?></td>
                        </tr>
                    </table>  
                    </div>
						
                    <div class="panel-footer text-center">
                        <center>
					<br />
						<a href="<?= base_url('panel/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'])?>" class="btn btn-primary btn-sm"><i class="fa fa-edit fa-fw"></i> แก้ไข</a>
					<br /> 
					<br /> 
                        <a href="<?= base_url('admin/cekuser/'.$row['Id']) ?>" class="btn btn-default btn-sm"><i class="fa fa-group fa-fw"></i> ตรวจสอบผู้ใช้งาน</a>
					<br /> 
					<br /> 
                        <a href="<?= base_url('panel/administrator/edit/'.str_replace(' ','-',$row['ServerName']).'/'.$row['Id'].'/del' ) ?>" class="btn btn-danger btn-sm"><i class="fa d-inline fa fa-trash"></i> ลบเซิร์ฟเวอร์</a>
					<br /> 
					<br /> 
                        </center>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
