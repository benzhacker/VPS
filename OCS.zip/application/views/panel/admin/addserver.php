<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
               เพิ่มเซิร์ฟเวอร์
			   </h1>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12">
				<?php if (isset($message)) { echo $message; }?>               
            </div>
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> ตั้งค่าเซิร์ฟเวอร์
                </div>
                <div class="panel-body">
                    <form action="<?= base_url('panel/administrator/'.$_SESSION['username'].'/'.'addserver') ?>" method="POST">
                        <div class="form-group">
                            <label>ชื่อเซิร์ฟเวอร์</label>
                            <input class="form-control" placeholder="Server Demo 1" name="ServerName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ประเทศ</label>
                            <select class="form-control" name="Location">
								<?php foreach($this->user_model->get_country() as $row):?>
								<option value="<?= $row['Country'] ?>"><?= $row['Country'] ?></option>
								<?php endforeach;?>
							</select>
                        </div>
                        <div class="form-group">
                            <label>ไอพี / โฮสเนม</label>
                            <input class="form-control" placeholder="192.168.1.1 หรือ www.byvpn.net" name="HostName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ราคา / เดือน</label>
                            <div class="input-group">
                                <input class="form-control" placeholder="10" name="Price" type="number" step="10" required>
                                <span class="input-group-addon"> บาท / เดือน</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านเข้าเซิร์ฟเวอร์</label>
                            <input class="form-control" placeholder="RootPasswd" name="RootPasswd" type="text">
                        </div>
                        <input type="submit" class="btn btn-primary" value="บันทึก">
                        <a href="<?= base_url('panel/administrator/'.$_SESSION['username'].'/'.'server') ?>" class="btn btn-default">ยกเลิก</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
