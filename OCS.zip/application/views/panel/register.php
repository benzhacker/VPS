<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="container">
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="navbar-header">
          
            <a class="navbar-brand" href="/"><i class="fa fa-rocket"></i>   nong vpn</a> <p class="navbar-text">ssh และ openvpn </p>
        </div>

        
    </nav>
</div>
<style type="text/css">
body {
	background-image: url(http://mmt-server.tk/images/anime-1517140307917-7435.jpg);
}
</style>

<div class="container" style=     "margin-bottom: 30px;">
	<div class="row">
		<div class="col-md-4"></div>
		     <div class="col-md-4" style="margin-top:80px;" >
          <div class="page-header">
                    <h1 align="center">สมัครสมาชิก</h1>
  </div>
			<?= form_open() ?>
				<div class="form-group">
					<label for="username">ชื่อผู้ใช้งาน</label>
					<input type="text" class="form-control" id="username" name="username" placeholder="Username">
					<p class="help-block">กรุณากรอก 6 ตัวขึ้นไป ( ภาษาอังกฤษเท่านั้น )</p>
				</div>
				<div class="form-group">
					<label for="email">อีเมล์</label>
					<input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
					<p class="help-block">กรุณากรอก อีเมลล์ ของท่าน ( ไม่จำเป็นต้องมีอยู่จริงก็ได้ครับ )</p>
				</div>
				<div class="form-group">
					<label for="password">รหัสผ่าน</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="Enter a password">
					<p class="help-block">ใส่ตัวเลข 6 หลักขึ้นไป</p>
				</div>
				<div class="form-group">
					<label for="password_confirm">ยืนยันรหัสผ่าน</label>
					<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="Confirm your password">
					<p class="help-block">ใส่รหัสผ่านอีกครั้ง</p>
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-primary" value="สมัครสมาชิก">
					<a href="<?= base_url('panel/login') ?>" class="btn btn-warning" > กลับไปหน้า Login</a>	
				</div>
			</form>
		</div>
				</div>
			</div>
		</div>
	</div><!-- .row -->
</div><!-- .container -->
