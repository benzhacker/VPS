<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0; bg-color:red">
<div class="navbar-header">
<a class="navbar-brand" href="/"><i class=""></i>MMT-VPN.TK</a> <p class="navbar-text">บริการ OpenVPN และ SSH</p>
</div>
</nav>
<section id="#login">
     <div class="container">
     <div class="row ver-parent">
     <div class="col-md-4 col-md-offset-4 ver-center">
          <p>&nbsp;</p>
     <h2 align="center" class="block-title block-title--left editContent">
	 <p class="text-success">เข้าสู่ระบบ</p>
	 </h2>
                    <div class="panel-body">
                        <?= form_open() ?>
                            <fieldset>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user fa-fw">
										</i>
										</span>
                                        <input class="form-control" placeholder="Username" name="username" type="text" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                                        <input class="form-control" placeholder="Password" name="password" type="password" required>
                                    </div>
                                </div>
      <div class="col-lg-12"> <span>
	  </span>
         <button class="btn btn-info btn-block" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> เข้าสู่ระบบ</button>
         <a href="<?= base_url('panel/register') ?>" class="btn btn-block btn btn-warning">
		 <i class="fa fa-ravelry">
		 </i>
                  สมัครสมาชิก คลิก</a>
         <a href="http://mmt-server.tk/Programs/VPN%20Anime%20BY%20MMT%20VPN.apk" class="btn btn-block btn btn-danger"><i class="fa fa-ravelry"></i>
                   ดาวโหลด APP แอนดรอย คลิก</a>
         <a href="http://mmt-server.tk/Programs/openvpncom.rar" class="btn btn-block btn btn-success"><i class="fa fa-ravelry"></i>
                  ดาวโหลด โปรแกรม windows คลิก</a>
       </div>
    <style type="text/css">
<!--
body {

	background-image: url(http://mmt-server.tk/images/ANIME-PICTURES.NET_-_525166-1920x1080-original-saraki-single-highres-wide+image-brown+hair.jpg);
	background-attachment: fixed;
	background-position: center top;
	margin: 0px;
	padding: 0px;
}
-->
</style>

                </div>

            </div>
          
        </div>
  
    </div>
     
</section>
