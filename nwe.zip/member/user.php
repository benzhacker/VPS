<?php 
SESSION_START();
if ($_POST['wallet'] == '') {
include 'config.php';
}else {
include 'config.php';
}
if(!$_SESSION['user']['username']){
header("location: login.php");
}
;echo '	<html>
	
 <head> 
  <meta charset="utf-8"> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge"> 
  <h2><title>AUTO WALLET</title></h2>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&amp;subset=thai,latin" rel="stylesheet" type="text/css"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
  <style>
		body {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
		h1 {
		  font-family: \'Kanit\', sans-serif;
		  font-family: \'Pridi\', serif;
		  font-family: \'Mitr\', sans-serif;
		}
    </style> 
    <style type="text/css">
body {
background-image: url(\'/asset/imega/bg.JPG\');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
 </head>

 

<body class="hold-transition register-page"> 
  <div class="register-box"> 
   <section class="content"> 
    <div class="main-panel"> 
     <div class="content"> 
      <div class="container-fluid"> 
       <div class="row"> 
        
         <div class="card card-profile"> 
          <div class="card-avatar"> 
          </div> 
          <div class="content"> 
       
         <center>
             
  ';
$sql = "select * from users where username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);
;echo '           
           <form action="user.php" method="post"> 
            <div class="form-group"> 
                
                  <center> <a href="#pablo"> <img class="img" src="logo.png"> </a> </center>
	<center>
           <p> <b> <font color="ffffff"> นำเลขที่อ้างอิงจากการโอนมาใส่</font></b><p>  
             
             <p><b><font color="ffffff"> ดูจากรายงานที่แอพ wallet <a href="/panel/reseller/smilevpn/addsaldo-via-hp">ดูตัวอย่าง</a></font></b></p>
             
             <p><b><font color="ffffff"> ชื่อบัญชี ';echo $result['username'];;echo '</b> </p> 
         
                 
';
if ($_POST['wallet'] == '') {
;echo '	<p><b>เครดิตที่เหลือ ';echo $result['saldo'];;echo ' บาท</b></font>
              ';if (isset($user->saldo)) {echo $user->saldo;};echo ' 
	';
}else {
include 'wallet.php';
}
;echo '	<p><p>
             <input type="number" style="width:210px; border:1px" class="form-control text-center" maxlength="20" name="wallet"  placeholder="ใส่เลขอ้างอิง 14หลัก" autofocus>
			 <input name="member" type="hidden" value="';echo $result['username'];;echo '" id="member">
           <br><br>
            <input class="btn btn-info btn-round" class="form-control" type="submit" value="ยืนยันเลขอ้างอิง" name="wallet" onclick="this.disabled=1;this.value=\'รอสักครู่กำลังตรวจสอบเลขอ้างอิง...\';document.forms[0].submit();loading()" style="height:40px;font-size16px"> 
           </form> 
          </div> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
     <div>
     </div> 
    </div>
   </section>
   <h1></h1>
   <center>
   <p><a href="/">กลับหน้าแรก</a></p>
   <p><a href="http://line.me/ti/p/%40cok9035j">🔔 แจ้งปัญหาคลิกที่นี่...</a></p>
   </center>
  </div> 
  <div class="amp-viewer-wrapper amp-viewer-is-touch" style="display: none;">
   <div class="amp-viewer">
    <div class="amp-viewer-header" style="transform: translate3d(0px, 0px, 0px);">
     <span class="amp-viewer-icon amp-viewer-icon-close">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewbox="0 0 100 125" style="enable-background:new 0 0 100 100;" xml:space="preserve">
       <path d="M88.8,77.5L60.6,49.3l28.2-28.2c1.2-1.2,1.2-3.1,0-4.2l-8.5-8.5L50,38.7L19.6,8.3l-8.5,8.5c-1.2,1.2-1.2,3.1,0,4.2  l28.2,28.2L11.2,77.5c-1.2,1.2-1.2,3.1,0,4.2l8.5,8.5L50,59.9l30.4,30.4l8.5-8.5C90,80.6,90,78.7,88.8,77.5z"></path>
      </svg></span>
     <div class="amp-viewer-header-main"></div>
    </div>
    <div class="amp-viewer-body" style="transform: translate3d(0px, 0px, 0px);"></div>
   </div>
  </div>
  </center>
 </body>
</html>
';
$image_thumbnail_url = '';
$image_fullsize_url = '';
$sticker_package_id = '';
$sticker_id = '';
$message_data = array(
'message'=>$str,
'imageThumbnail'=>$image_thumbnail_url,
'imageFullsize'=>$image_fullsize_url,
'stickerPackageId'=>$sticker_package_id,
'stickerId'=>$sticker_id
);
$result = send_notify_message($line_api,$access_token,$message_data);
print_r($result);
function send_notify_message($line_api,$access_token,$message_data)
{
$headers = array('Method: POST','Content-type: multipart/form-data','Authorization: Bearer '.$access_token );
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$line_api);
curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($ch,CURLOPT_POSTFIELDS,$message_data);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$result = curl_exec($ch);
if(curl_error($ch))
{
$return_array = array( 'status'=>'000: send fail','message'=>curl_error($ch) );
}
else
{
$return_array = json_decode($result,true);
}
curl_close($ch);
return $retur_array;
}; ?>