<?php echo '
	

';
include('smile.php');
$id = $_REQUEST[id];
$saldo = $_REQUEST[saldo];
$user = $_REQUEST[username];
$sql="Update users Set username='$_REQUEST[username]' , saldo='$_REQUEST[saldo]' where  id ='$_REQUEST[id]'  ";
$result = mysqli_query($con,$sql) or die ("Error in query: $sql ".mysqli_error());
mysqli_close($con);
if($result){
echo "<script type='text/javascript'>";
echo "alert('แก้ไขเครดิตให้เหลือ $_REQUEST[saldo] บาท เรียบร้อย');";
echo "window.location = '/admin/view_users'; ";
echo "</script>";
}
else{
echo "<script type='text/javascript'>";
echo "alert('Error back to Update again');";
echo "</script>";
}; ?>