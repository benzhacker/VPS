<?php echo '<meta charset="UTF-8">

	

';
include('smile.php');
$sql="Update users Set  saldo=saldo+'".$_REQUEST[saldo]."' where  id ='".$_REQUEST[id]."' ";
$result = mysqli_query($con,$sql) or die ("Error in query: $sql ".mysqli_error());
mysqli_close($con);
if($result){
echo "<script type='text/javascript'>";
echo "alert('เพิ่มเครดิต $_REQUEST[saldo] บาท เรียบร้อย');";
echo "window.location = '/admin/view_users'; ";
echo "</script>";
}
else{
echo "<script type='text/javascript'>";
echo "alert('Error back to Update again');";
echo "</script>";
}; ?>